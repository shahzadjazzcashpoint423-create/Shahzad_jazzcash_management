package com.example.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.Money
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BalanceAccount
import com.example.data.model.ServiceType
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.ui.components.StatMetricCard
import com.example.ui.localization.AppStrings
import com.example.ui.screens.expenses.AddExpenseDialog
import com.example.ui.screens.transactions.AddTransactionDialog
import com.example.ui.theme.EasypaisaGreen
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.JazzBrandRed
import com.example.ui.theme.JazzCashRed
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.TelenorBrandBlue
import com.example.ui.theme.UfoneBrandOrange
import com.example.ui.theme.ZongBrandMagenta
import com.example.viewmodel.ShopViewModel

@Composable
fun DashboardScreen(
    viewModel: ShopViewModel,
    onNavigateToTransactions: () -> Unit,
    onNavigateToBalances: () -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToClosing: () -> Unit
) {
    val language by viewModel.language.collectAsState()
    val balanceMap by viewModel.balanceMap.collectAsState()
    val todayTransactions by viewModel.todayTransactions.collectAsState()
    val todayVolume by viewModel.todayVolume.collectAsState()
    val todayCount by viewModel.todayCount.collectAsState()
    val todayProfit by viewModel.todayNetProfit.collectAsState()
    val todayExpenses by viewModel.todayExpensesTotal.collectAsState()

    var showAddTxDialog by remember { mutableStateOf(false) }
    var presetService by remember { mutableStateOf(ServiceType.JAZZCASH) }
    var presetTxType by remember { mutableStateOf(TransactionType.CASH_IN) }

    var showAddExpenseDialog by remember { mutableStateOf(false) }

    val cashInHand = balanceMap[BalanceAccount.CASH_IN_HAND.key] ?: 0.0
    val jazzCashBal = balanceMap[BalanceAccount.JAZZCASH.key] ?: 0.0
    val easypaisaBal = balanceMap[BalanceAccount.EASYPAISA.key] ?: 0.0
    val jazzLoadBal = balanceMap[BalanceAccount.JAZZ_LOAD.key] ?: 0.0
    val zongLoadBal = balanceMap[BalanceAccount.ZONG_LOAD.key] ?: 0.0
    val telenorLoadBal = balanceMap[BalanceAccount.TELENOR_LOAD.key] ?: 0.0
    val ufoneLoadBal = balanceMap[BalanceAccount.UFONE_LOAD.key] ?: 0.0

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // Hero Cash In Hand Card
            HeroCashCard(
                cashInHand = cashInHand,
                todayProfit = todayProfit,
                language = language,
                onQuickAdd = {
                    presetService = ServiceType.JAZZCASH
                    presetTxType = TransactionType.CASH_IN
                    showAddTxDialog = true
                }
            )
        }

        // Today's 3 Metrics Overview Row (Transactions, Profit, Expenses)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricMiniPill(
                    title = AppStrings.get(AppStrings.TODAY_TRANSACTIONS, language),
                    value = "$todayCount (${AppStrings.formatPkr(todayVolume, language)})",
                    icon = Icons.Default.ReceiptLong,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                MetricMiniPill(
                    title = AppStrings.get(AppStrings.TODAY_PROFIT, language),
                    value = AppStrings.formatPkr(todayProfit, language),
                    icon = Icons.Default.TrendingUp,
                    tint = ProfitGreen,
                    modifier = Modifier.weight(1f)
                )
                MetricMiniPill(
                    title = AppStrings.get(AppStrings.TODAY_EXPENSES, language),
                    value = AppStrings.formatPkr(todayExpenses, language),
                    icon = Icons.Default.TrendingDown,
                    tint = ExpenseRed,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Quick Actions Section
        item {
            Text(
                text = AppStrings.get(AppStrings.QUICK_ACTIONS, language),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickActionButton(
                    label = AppStrings.get(AppStrings.CASH_IN, language),
                    icon = Icons.Default.ArrowDownward,
                    color = ProfitGreen,
                    modifier = Modifier.weight(1f),
                    testTag = "btn_quick_cash_in"
                ) {
                    presetService = ServiceType.JAZZCASH
                    presetTxType = TransactionType.CASH_IN
                    showAddTxDialog = true
                }
                QuickActionButton(
                    label = AppStrings.get(AppStrings.CASH_OUT, language),
                    icon = Icons.Default.ArrowUpward,
                    color = JazzCashRed,
                    modifier = Modifier.weight(1f),
                    testTag = "btn_quick_cash_out"
                ) {
                    presetService = ServiceType.JAZZCASH
                    presetTxType = TransactionType.CASH_OUT
                    showAddTxDialog = true
                }
                QuickActionButton(
                    label = AppStrings.get(AppStrings.BILL_PAYMENT, language),
                    icon = Icons.Default.Receipt,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f),
                    testTag = "btn_quick_bill"
                ) {
                    presetService = ServiceType.EASYPAISA
                    presetTxType = TransactionType.BILL_PAYMENT
                    showAddTxDialog = true
                }
                QuickActionButton(
                    label = AppStrings.get(AppStrings.MOBILE_LOAD, language),
                    icon = Icons.Default.PhoneAndroid,
                    color = ZongBrandMagenta,
                    modifier = Modifier.weight(1f),
                    testTag = "btn_quick_load"
                ) {
                    presetService = ServiceType.JAZZ_LOAD
                    presetTxType = TransactionType.MOBILE_LOAD
                    showAddTxDialog = true
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { showAddExpenseDialog = true },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_quick_add_expense"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(AppStrings.get(AppStrings.ADD_EXPENSE, language), fontSize = 12.sp)
                }

                Button(
                    onClick = onNavigateToClosing,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_quick_daily_closing"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.EventNote, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(AppStrings.get(AppStrings.DAILY_CLOSING_BTN, language), fontSize = 12.sp)
                }
            }
        }

        // Live Service & Load Balances Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = AppStrings.get(AppStrings.BALANCES, language),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                TextButton(
                    onClick = onNavigateToBalances,
                    modifier = Modifier.testTag("btn_view_all_balances")
                ) {
                    Text(if (language == com.example.data.model.AppLanguage.URDU) "مکمل بیلنس" else "View All")
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // JazzCash & Easypaisa row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatMetricCard(
                        title = AppStrings.get(AppStrings.JAZZCASH_BAL, language),
                        value = AppStrings.formatPkr(jazzCashBal, language),
                        icon = Icons.Default.AccountBalance,
                        iconTint = JazzCashRed,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            presetService = ServiceType.JAZZCASH
                            showAddTxDialog = true
                        }
                    )
                    StatMetricCard(
                        title = AppStrings.get(AppStrings.EASYPAISA_BAL, language),
                        value = AppStrings.formatPkr(easypaisaBal, language),
                        icon = Icons.Default.AccountBalance,
                        iconTint = EasypaisaGreen,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            presetService = ServiceType.EASYPAISA
                            showAddTxDialog = true
                        }
                    )
                }

                // 4 Load Balances Row (Jazz, Zong, Telenor, Ufone)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    LoadPillCard(
                        title = "Jazz",
                        value = AppStrings.formatPkr(jazzLoadBal, language),
                        color = JazzBrandRed,
                        modifier = Modifier.weight(1f)
                    )
                    LoadPillCard(
                        title = "Zong",
                        value = AppStrings.formatPkr(zongLoadBal, language),
                        color = ZongBrandMagenta,
                        modifier = Modifier.weight(1f)
                    )
                    LoadPillCard(
                        title = "Telenor",
                        value = AppStrings.formatPkr(telenorLoadBal, language),
                        color = TelenorBrandBlue,
                        modifier = Modifier.weight(1f)
                    )
                    LoadPillCard(
                        title = "Ufone",
                        value = AppStrings.formatPkr(ufoneLoadBal, language),
                        color = UfoneBrandOrange,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Today's Recent Transactions Preview
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (language == com.example.data.model.AppLanguage.URDU) "آج کے سودے" else "Today's Transactions",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                TextButton(
                    onClick = onNavigateToTransactions,
                    modifier = Modifier.testTag("btn_view_all_transactions")
                ) {
                    Text(if (language == com.example.data.model.AppLanguage.URDU) "تمام دیکھیں" else "View All")
                }
            }
        }

        if (todayTransactions.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.ReceiptLong,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (language == com.example.data.model.AppLanguage.URDU) "آج ابھی تک کوئی سودا درج نہیں ہوا" else "No transactions logged today yet",
                            style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                }
            }
        } else {
            items(todayTransactions.take(5)) { tx ->
                DashboardTransactionItem(tx = tx, language = language)
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showAddTxDialog) {
        AddTransactionDialog(
            initialService = presetService,
            initialType = presetTxType,
            language = language,
            onDismiss = { showAddTxDialog = false },
            onSave = { service, type, amount, fee, commission, customer, notes ->
                viewModel.addTransaction(
                    service = service,
                    transactionType = type,
                    amount = amount,
                    serviceFee = fee,
                    commission = commission,
                    customerNumber = customer,
                    notes = notes,
                    onDone = { showAddTxDialog = false }
                )
            }
        )
    }

    if (showAddExpenseDialog) {
        AddExpenseDialog(
            language = language,
            onDismiss = { showAddExpenseDialog = false },
            onSave = { category, amount, description, paidFrom ->
                viewModel.addExpense(
                    category = category,
                    amount = amount,
                    description = description,
                    paidFromAccount = paidFrom,
                    onDone = { showAddExpenseDialog = false }
                )
            }
        )
    }
}

@Composable
fun HeroCashCard(
    cashInHand: Double,
    todayProfit: Double,
    language: com.example.data.model.AppLanguage,
    onQuickAdd: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("hero_cash_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF0F5132),
                            Color(0xFF0B3B24)
                        )
                    )
                )
                .padding(20.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = AppStrings.get(AppStrings.CASH_IN_HAND, language),
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 13.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = AppStrings.formatPkr(cashInHand, language),
                            style = MaterialTheme.typography.headlineMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 28.sp
                            )
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.15f))
                            .clickable { onQuickAdd() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add Transaction",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.TrendingUp,
                            contentDescription = null,
                            tint = Color(0xFFA3E635),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${AppStrings.get(AppStrings.TODAY_PROFIT, language)}: ${AppStrings.formatPkr(todayProfit, language)}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.White.copy(alpha = 0.95f),
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }

                    Text(
                        text = "PKR Cash Drawer",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun MetricMiniPill(
    title: String,
    value: String,
    icon: ImageVector,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = tint,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 10.sp
                    ),
                    maxLines = 1
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface
                ),
                maxLines = 1
            )
        }
    }
}

@Composable
fun QuickActionButton(
    label: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .testTag(testTag),
        color = color.copy(alpha = 0.12f),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = color,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = color,
                    fontSize = 11.sp
                ),
                maxLines = 1
            )
        }
    }
}

@Composable
fun LoadPillCard(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = color,
                    fontSize = 11.sp
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurface
                ),
                maxLines = 1
            )
        }
    }
}

@Composable
fun DashboardTransactionItem(
    tx: TransactionEntity,
    language: com.example.data.model.AppLanguage
) {
    val sType = ServiceType.fromCode(tx.service)
    val tType = TransactionType.fromCode(tx.transactionType)

    val serviceColor = when (sType) {
        ServiceType.JAZZCASH -> JazzCashRed
        ServiceType.EASYPAISA -> EasypaisaGreen
        ServiceType.JAZZ_LOAD -> JazzBrandRed
        ServiceType.ZONG_LOAD -> ZongBrandMagenta
        ServiceType.TELENOR_LOAD -> TelenorBrandBlue
        ServiceType.UFONE_LOAD -> UfoneBrandOrange
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(serviceColor.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (tType) {
                        TransactionType.CASH_IN -> Icons.Default.ArrowDownward
                        TransactionType.CASH_OUT -> Icons.Default.ArrowUpward
                        TransactionType.BILL_PAYMENT -> Icons.Default.Receipt
                        TransactionType.MOBILE_LOAD -> Icons.Default.PhoneAndroid
                        else -> Icons.Default.Money
                    },
                    contentDescription = null,
                    tint = serviceColor,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (language == com.example.data.model.AppLanguage.URDU) sType.titleUr else sType.titleEn,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "• ${if (language == com.example.data.model.AppLanguage.URDU) tType.titleUr else tType.titleEn}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                    )
                }

                if (!tx.customerNumber.isNullOrBlank()) {
                    Text(
                        text = "Customer: ${tx.customerNumber}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = AppStrings.formatPkr(tx.amount, language),
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )
                if (tx.netProfit > 0) {
                    Text(
                        text = "+${AppStrings.formatPkr(tx.netProfit, language)} profit",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = ProfitGreen,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 10.sp
                        )
                    )
                }
            }
        }
    }
}
