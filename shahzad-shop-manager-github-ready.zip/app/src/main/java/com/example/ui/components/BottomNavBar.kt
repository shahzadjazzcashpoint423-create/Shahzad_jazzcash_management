package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.ui.localization.AppStrings

enum class AppTab(
    val titleKey: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    HOME(AppStrings.DASHBOARD, Icons.Filled.Home, Icons.Outlined.Home, "tab_home"),
    TRANSACTIONS(AppStrings.TRANSACTIONS, Icons.Filled.ReceiptLong, Icons.Outlined.ReceiptLong, "tab_transactions"),
    BALANCES(AppStrings.BALANCES, Icons.Filled.AccountBalanceWallet, Icons.Outlined.AccountBalanceWallet, "tab_balances"),
    REPORTS(AppStrings.REPORTS, Icons.Filled.Assessment, Icons.Outlined.Assessment, "tab_reports"),
    SETTINGS(AppStrings.SETTINGS, Icons.Filled.Settings, Icons.Outlined.Settings, "tab_settings")
}

@Composable
fun BottomNavBar(
    currentTab: AppTab,
    onTabSelected: (AppTab) -> Unit,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier
    ) {
        AppTab.entries.forEach { tab ->
            val isSelected = currentTab == tab
            val label = AppStrings.get(tab.titleKey, language)

            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(tab) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                        contentDescription = label
                    )
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1
                    )
                },
                modifier = Modifier.testTag(tab.testTag),
                alwaysShowLabel = true
            )
        }
    }
}
