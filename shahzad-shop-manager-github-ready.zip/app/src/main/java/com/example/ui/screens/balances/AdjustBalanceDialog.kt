package com.example.ui.screens.balances

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage
import com.example.data.model.BalanceAccount
import com.example.ui.localization.AppStrings

@Composable
fun AdjustBalanceDialog(
    accountKey: String,
    currentBalance: Double,
    language: AppLanguage,
    onDismiss: () -> Unit,
    onSave: (newBalance: Double, reason: String) -> Unit
) {
    var newBalanceText by remember { mutableStateOf(if (currentBalance == 0.0) "" else currentBalance.toString()) }
    var reasonText by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val account = BalanceAccount.fromKey(accountKey)
    val accountName = if (language == AppLanguage.URDU) account.nameUr else account.nameEn

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "${AppStrings.get(AppStrings.ADJUST_BALANCE, language)}: $accountName",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "${if (language == AppLanguage.URDU) "موجودہ بیلنس" else "Current Balance"}: ${AppStrings.formatPkr(currentBalance, language)}",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = newBalanceText,
                    onValueChange = {
                        newBalanceText = it
                        errorMessage = null
                    },
                    label = { Text(if (language == AppLanguage.URDU) "نیا درست بیلنس (روپے)" else "New Correct Balance (PKR)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_adjust_balance_val"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = reasonText,
                    onValueChange = { reasonText = it },
                    label = { Text(if (language == AppLanguage.URDU) "وجہ / تفصیل (مثلاً اوپننگ بیلنس یا بینک ڈپازٹ)" else "Reason (e.g. Opening Balance, Bank Deposit)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_adjust_balance_reason"),
                    singleLine = true
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = errorMessage ?: "",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val newBal = newBalanceText.toDoubleOrNull()
                    if (newBal == null || newBal < 0) {
                        errorMessage = if (language == AppLanguage.URDU) "براہ کرم درست مثبت رقم درج کریں" else "Please enter a valid positive amount"
                        return@Button
                    }
                    val reason = if (reasonText.isBlank()) "Manual adjustment" else reasonText
                    onSave(newBal, reason)
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.testTag("save_adjust_balance_btn")
            ) {
                Text(AppStrings.get(AppStrings.SAVE, language))
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_adjust_balance_btn")
            ) {
                Text(AppStrings.get(AppStrings.CANCEL, language))
            }
        }
    )
}
