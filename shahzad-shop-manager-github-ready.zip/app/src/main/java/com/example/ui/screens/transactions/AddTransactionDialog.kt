package com.example.ui.screens.transactions

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.ServiceType
import com.example.data.model.TransactionType
import com.example.ui.localization.AppStrings
import com.example.ui.theme.EasypaisaGreen
import com.example.ui.theme.JazzBrandRed
import com.example.ui.theme.JazzCashRed
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.TelenorBrandBlue
import com.example.ui.theme.UfoneBrandOrange
import com.example.ui.theme.ZongBrandMagenta

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddTransactionDialog(
    initialService: ServiceType = ServiceType.JAZZCASH,
    initialType: TransactionType = TransactionType.CASH_IN,
    language: AppLanguage,
    onDismiss: () -> Unit,
    onSave: (
        service: String,
        type: String,
        amount: Double,
        fee: Double,
        commission: Double,
        customerNumber: String?,
        notes: String?
    ) -> Unit
) {
    var selectedService by remember { mutableStateOf(initialService) }
    var selectedType by remember { mutableStateOf(initialType) }

    var amountText by remember { mutableStateOf("") }
    var feeText by remember { mutableStateOf("") }
    var commissionText by remember { mutableStateOf("") }
    var customerNumberText by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // If mobile load service selected, ensure type is MOBILE_LOAD
    val isMobileLoadService = selectedService in listOf(
        ServiceType.JAZZ_LOAD,
        ServiceType.ZONG_LOAD,
        ServiceType.TELENOR_LOAD,
        ServiceType.UFONE_LOAD
    )

    val availableTypes = if (isMobileLoadService) {
        listOf(TransactionType.MOBILE_LOAD)
    } else {
        listOf(
            TransactionType.CASH_IN,
            TransactionType.CASH_OUT,
            TransactionType.BILL_PAYMENT,
            TransactionType.SERVICE_FEE
        )
    }

    if (selectedType !in availableTypes) {
        selectedType = availableTypes.first()
    }

    val parsedAmount = amountText.toDoubleOrNull() ?: 0.0
    val parsedFee = feeText.toDoubleOrNull() ?: 0.0
    val parsedCommission = commissionText.toDoubleOrNull() ?: 0.0

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = AppStrings.get(AppStrings.NEW_TRANSACTION, language),
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Service Selector Chips
                Text(
                    text = AppStrings.get(AppStrings.SERVICE, language),
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(6.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    ServiceType.entries.forEach { s ->
                        val isSelected = selectedService == s
                        val color = when (s) {
                            ServiceType.JAZZCASH -> JazzCashRed
                            ServiceType.EASYPAISA -> EasypaisaGreen
                            ServiceType.JAZZ_LOAD -> JazzBrandRed
                            ServiceType.ZONG_LOAD -> ZongBrandMagenta
                            ServiceType.TELENOR_LOAD -> TelenorBrandBlue
                            ServiceType.UFONE_LOAD -> UfoneBrandOrange
                        }

                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .border(
                                    1.dp,
                                    if (isSelected) color else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    selectedService = s
                                }
                                .testTag("select_service_${s.code}"),
                            color = if (isSelected) color.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = if (language == AppLanguage.URDU) s.titleUr else s.titleEn,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) color else MaterialTheme.colorScheme.onSurface
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Transaction Type Selector
                Text(
                    text = AppStrings.get(AppStrings.TYPE, language),
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(6.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    availableTypes.forEach { t ->
                        val isSelected = selectedType == t
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .border(
                                    1.dp,
                                    if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { selectedType = t }
                                .testTag("select_type_${t.code}"),
                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = if (language == AppLanguage.URDU) t.titleUr else t.titleEn,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Amount Input
                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it
                        errorMessage = null
                    },
                    label = { Text(AppStrings.get(AppStrings.AMOUNT, language)) },
                    placeholder = { Text("e.g. 1000") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_tx_amount"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Customer Mobile Number (Optional)
                OutlinedTextField(
                    value = customerNumberText,
                    onValueChange = { customerNumberText = it },
                    label = { Text(AppStrings.get(AppStrings.CUSTOMER_NUMBER, language)) },
                    placeholder = { Text("03001234567") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_tx_customer"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Fees & Commission in one row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = feeText,
                        onValueChange = { feeText = it },
                        label = { Text(AppStrings.get(AppStrings.SERVICE_FEE, language), fontSize = 11.sp) },
                        placeholder = { Text("20") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_tx_fee"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = commissionText,
                        onValueChange = { commissionText = it },
                        label = { Text(AppStrings.get(AppStrings.COMMISSION, language), fontSize = 11.sp) },
                        placeholder = { Text("5") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_tx_commission"),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Notes Input
                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text(AppStrings.get(AppStrings.NOTES, language)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_tx_notes"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Real-time Accounting Impact Explanation Card
                if (parsedAmount > 0 || parsedFee > 0) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                        )
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (language == AppLanguage.URDU) "بیلنس تبدیلی کی تفصیل:" else "Automatic Balance Impact:",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            val explanation = when (selectedType) {
                                TransactionType.CASH_IN -> {
                                    if (language == AppLanguage.URDU)
                                        "• کیش ان ہینڈ میں +${AppStrings.formatPkr(parsedAmount + parsedFee, language)} اضافہ ہوگا\n• والٹ میں سے -${AppStrings.formatPkr(parsedAmount, language)} کٹوتی ہوگی\n• خالص منافع: +${AppStrings.formatPkr(parsedFee + parsedCommission, language)}"
                                    else
                                        "• Cash in Hand increases by ${AppStrings.formatPkr(parsedAmount + parsedFee, language)}\n• Wallet decreases by ${AppStrings.formatPkr(parsedAmount, language)}\n• Net Profit: +${AppStrings.formatPkr(parsedFee + parsedCommission, language)}"
                                }
                                TransactionType.CASH_OUT -> {
                                    if (language == AppLanguage.URDU)
                                        "• کیش ان ہینڈ میں سے -${AppStrings.formatPkr(parsedAmount - parsedFee, language)} جائے گا\n• والٹ میں +${AppStrings.formatPkr(parsedAmount, language)} شامل ہوگا\n• خالص منافع: +${AppStrings.formatPkr(parsedFee + parsedCommission, language)}"
                                    else
                                        "• Cash in Hand pays out ${AppStrings.formatPkr(parsedAmount - parsedFee, language)}\n• Wallet gains +${AppStrings.formatPkr(parsedAmount, language)}\n• Net Profit: +${AppStrings.formatPkr(parsedFee + parsedCommission, language)}"
                                }
                                TransactionType.BILL_PAYMENT -> {
                                    if (language == AppLanguage.URDU)
                                        "• کیش ان ہینڈ میں +${AppStrings.formatPkr(parsedAmount + parsedFee, language)} جمع ہوگا\n• والٹ میں سے بل رقم -${AppStrings.formatPkr(parsedAmount, language)} کٹے گی\n• خالص منافع: +${AppStrings.formatPkr(parsedFee + parsedCommission, language)}"
                                    else
                                        "• Cash in Hand gains ${AppStrings.formatPkr(parsedAmount + parsedFee, language)}\n• Wallet pays bill -${AppStrings.formatPkr(parsedAmount, language)}\n• Net Profit: +${AppStrings.formatPkr(parsedFee + parsedCommission, language)}"
                                }
                                TransactionType.MOBILE_LOAD -> {
                                    if (language == AppLanguage.URDU)
                                        "• کیش ان ہینڈ میں +${AppStrings.formatPkr(parsedAmount + parsedFee, language)} وصول ہوگا\n• سم لوڈ بیلنس میں سے -${AppStrings.formatPkr(parsedAmount, language)} کٹے گا\n• خالص منافع: +${AppStrings.formatPkr(parsedFee + parsedCommission, language)}"
                                    else
                                        "• Cash in Hand gains ${AppStrings.formatPkr(parsedAmount + parsedFee, language)}\n• SIM Load decreases -${AppStrings.formatPkr(parsedAmount, language)}\n• Net Profit: +${AppStrings.formatPkr(parsedFee + parsedCommission, language)}"
                                }
                                else -> {
                                    "• Net Profit: +${AppStrings.formatPkr(parsedFee + parsedCommission, language)}"
                                }
                            }
                            Text(
                                text = explanation,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp)
                            )
                        }
                    }
                }

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorMessage ?: "",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull() ?: 0.0
                    if (amount <= 0 && selectedType != TransactionType.SERVICE_FEE) {
                        errorMessage = if (language == AppLanguage.URDU) "براہ کرم درست رقم درج کریں" else "Please enter a valid amount"
                        return@Button
                    }
                    val fee = feeText.toDoubleOrNull() ?: 0.0
                    val commission = commissionText.toDoubleOrNull() ?: 0.0

                    onSave(
                        selectedService.code,
                        selectedType.code,
                        amount,
                        fee,
                        commission,
                        customerNumberText,
                        notesText
                    )
                },
                modifier = Modifier.testTag("save_tx_submit_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text(AppStrings.get(AppStrings.SAVE, language))
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_tx_dialog_btn")
            ) {
                Text(AppStrings.get(AppStrings.CANCEL, language))
            }
        }
    )
}
