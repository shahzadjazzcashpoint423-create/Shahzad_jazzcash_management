package com.example.ui.screens.balances

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.BalanceAccount
import com.example.data.model.BalanceAccountEntity
import com.example.ui.localization.AppStrings
import com.example.ui.theme.EasypaisaGreen
import com.example.ui.theme.EmeraldGreenPrimary
import com.example.ui.theme.JazzBrandRed
import com.example.ui.theme.JazzCashRed
import com.example.ui.theme.TelenorBrandBlue
import com.example.ui.theme.UfoneBrandOrange
import com.example.ui.theme.ZongBrandMagenta
import com.example.viewmodel.ShopViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BalancesScreen(viewModel: ShopViewModel) {
    val language by viewModel.language.collectAsState()
    val accounts by viewModel.accounts.collectAsState()

    var accountToAdjust by remember { mutableStateOf<BalanceAccountEntity?>(null) }

    val totalAssets = accounts.sumOf { it.currentBalance }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Total Net Liquid Assets Header
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("card_total_assets"),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFF0F5132), Color(0xFF198754))
                        )
                    )
                    .padding(20.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (language == AppLanguage.URDU) "شاپ کے کل اثاثے (نقد + تمام والٹس)" else "Total Shop Capital (Cash + All Wallets)",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        )
                        Icon(
                            imageVector = Icons.Default.AccountBalanceWallet,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = AppStrings.formatPkr(totalAssets, language),
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            fontSize = 28.sp
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = if (language == AppLanguage.URDU) "تمام کھاتے اور والٹس" else "All Accounts & Wallets",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(accounts, key = { it.accountKey }) { account ->
                AccountRowCard(
                    account = account,
                    language = language,
                    onAdjust = { accountToAdjust = account }
                )
            }
            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    if (accountToAdjust != null) {
        val acc = accountToAdjust!!
        AdjustBalanceDialog(
            accountKey = acc.accountKey,
            currentBalance = acc.currentBalance,
            language = language,
            onDismiss = { accountToAdjust = null },
            onSave = { newBalance, reason ->
                viewModel.adjustBalance(acc.accountKey, newBalance, reason) {
                    accountToAdjust = null
                }
            }
        )
    }
}

@Composable
fun AccountRowCard(
    account: BalanceAccountEntity,
    language: AppLanguage,
    onAdjust: () -> Unit
) {
    val balanceAccount = BalanceAccount.fromKey(account.accountKey)
    val name = if (language == AppLanguage.URDU) balanceAccount.nameUr else balanceAccount.nameEn

    val (color, icon) = when (balanceAccount) {
        BalanceAccount.CASH_IN_HAND -> EmeraldGreenPrimary to Icons.Default.MonetizationOn
        BalanceAccount.JAZZCASH -> JazzCashRed to Icons.Default.AccountBalance
        BalanceAccount.EASYPAISA -> EasypaisaGreen to Icons.Default.AccountBalance
        BalanceAccount.JAZZ_LOAD -> JazzBrandRed to Icons.Default.PhoneAndroid
        BalanceAccount.ZONG_LOAD -> ZongBrandMagenta to Icons.Default.PhoneAndroid
        BalanceAccount.TELENOR_LOAD -> TelenorBrandBlue to Icons.Default.PhoneAndroid
        BalanceAccount.UFONE_LOAD -> UfoneBrandOrange to Icons.Default.PhoneAndroid
    }

    val dateFormat = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
    val lastUpdated = dateFormat.format(Date(account.lastUpdated))

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = name,
                    tint = color,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = name,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Updated: $lastUpdated",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = AppStrings.formatPkr(account.currentBalance, language),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            IconButton(
                onClick = onAdjust,
                modifier = Modifier
                    .size(36.dp)
                    .testTag("adjust_btn_${account.accountKey}")
            ) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "Adjust",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
