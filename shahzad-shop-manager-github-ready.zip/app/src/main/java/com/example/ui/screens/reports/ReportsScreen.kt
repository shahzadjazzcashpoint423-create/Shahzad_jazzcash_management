package com.example.ui.screens.reports

import android.content.Context
import android.content.Intent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.ui.components.StatMetricCard
import com.example.ui.localization.AppStrings
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.ProfitGreen
import com.example.viewmodel.ShopViewModel

enum class ReportTimeframe(val titleEn: String, val titleUr: String) {
    DAILY("Daily", "روزانہ"),
    WEEKLY("Weekly", "ہفتہ وار"),
    MONTHLY("Monthly", "ماہانہ"),
    TOTAL("All Time", "مجموعی")
}

@Composable
fun ReportsScreen(viewModel: ShopViewModel) {
    val context = LocalContext.current
    val language by viewModel.language.collectAsState()
    val todayProfit by viewModel.todayNetProfit.collectAsState()
    val weeklyProfit by viewModel.weeklyProfit.collectAsState()
    val monthlyProfit by viewModel.monthlyProfit.collectAsState()
    val totalProfit by viewModel.totalAllTimeProfit.collectAsState()

    val todayVolume by viewModel.todayVolume.collectAsState()
    val todayCount by viewModel.todayCount.collectAsState()
    val todayExpenses by viewModel.todayExpensesTotal.collectAsState()
    val allTransactions by viewModel.allTransactions.collectAsState()
    val allExpenses by viewModel.allExpenses.collectAsState()

    var selectedPeriod by remember { mutableStateOf(ReportTimeframe.DAILY) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Assessment,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = AppStrings.get(AppStrings.REPORTS, language),
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = if (language == AppLanguage.URDU) "منافع، اخراجات اور کاروباری اعداد و شمار" else "Profit, Expenses & Transaction Analytics",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }
            }
        }

        // Combined Profit Overview Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = AppStrings.get(AppStrings.PROFIT_BREAKDOWN, language),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ProfitPeriodPill(
                            title = AppStrings.get(AppStrings.DAILY_PROFIT, language),
                            amount = todayProfit,
                            language = language,
                            modifier = Modifier.weight(1f)
                        )
                        ProfitPeriodPill(
                            title = AppStrings.get(AppStrings.WEEKLY_PROFIT, language),
                            amount = weeklyProfit,
                            language = language,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ProfitPeriodPill(
                            title = AppStrings.get(AppStrings.MONTHLY_PROFIT, language),
                            amount = monthlyProfit,
                            language = language,
                            modifier = Modifier.weight(1f)
                        )
                        ProfitPeriodPill(
                            title = AppStrings.get(AppStrings.TOTAL_PROFIT, language),
                            amount = totalProfit,
                            language = language,
                            modifier = Modifier.weight(1f),
                            isHighlight = true
                        )
                    }
                }
            }
        }

        // Export and Sharing Actions
        item {
            Text(
                text = if (language == AppLanguage.URDU) "ایکسپورٹ و شیئرنگ" else "Export & Sharing Options",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Export to CSV / Excel
                Button(
                    onClick = {
                        val csv = viewModel.generateCsvExport()
                        shareTextReport(context, "Shahzad_Shop_Report.csv", csv, "text/csv")
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_export_csv"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (language == AppLanguage.URDU) "Excel / CSV ایکسپورٹ" else "Export Excel/CSV",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Share Summary Report
                OutlinedButton(
                    onClick = {
                        val summaryText = buildSummaryReportText(
                            todayProfit = todayProfit,
                            todayVolume = todayVolume,
                            todayCount = todayCount,
                            todayExpenses = todayExpenses,
                            language = language
                        )
                        shareTextReport(context, "Shop Daily Report", summaryText, "text/plain")
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_share_summary"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (language == AppLanguage.URDU) "رپورٹ شیئر کریں" else "Share Summary",
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Lifetime Accounting Statistics
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = if (language == AppLanguage.URDU) "مجموعی بزنس کے اہم اعداد و شمار" else "Lifetime Shop Performance",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    val allVol = allTransactions.sumOf { it.amount }
                    val allFees = allTransactions.sumOf { it.serviceFee }
                    val allComm = allTransactions.sumOf { it.commission }
                    val allExp = allExpenses.sumOf { it.amount }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(if (language == AppLanguage.URDU) "کل ٹرانزیکشنز کی تعداد" else "Total Transactions", style = MaterialTheme.typography.bodySmall)
                        Text("${allTransactions.size}", fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(if (language == AppLanguage.URDU) "کل ٹرن اوور (حجم)" else "Total Turnover Volume", style = MaterialTheme.typography.bodySmall)
                        Text(AppStrings.formatPkr(allVol, language), fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(if (language == AppLanguage.URDU) "کل فیس اور کمیشن" else "Total Fees & Commission", style = MaterialTheme.typography.bodySmall)
                        Text("+${AppStrings.formatPkr(allFees + allComm, language)}", color = ProfitGreen, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(if (language == AppLanguage.URDU) "کل اخراجات" else "Total Lifetime Expenses", style = MaterialTheme.typography.bodySmall)
                        Text("-${AppStrings.formatPkr(allExp, language)}", color = ExpenseRed, fontWeight = FontWeight.Bold)
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(if (language == AppLanguage.URDU) "خالص مجموعی منافع" else "Net Lifetime Profit", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        Text("+${AppStrings.formatPkr(totalProfit, language)}", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold, color = ProfitGreen))
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun ProfitPeriodPill(
    title: String,
    amount: Double,
    language: AppLanguage,
    modifier: Modifier = Modifier,
    isHighlight: Boolean = false
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isHighlight)
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
            else
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                ),
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = AppStrings.formatPkr(amount, language),
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (amount >= 0) ProfitGreen else ExpenseRed,
                    fontSize = 15.sp
                ),
                maxLines = 1
            )
        }
    }
}

private fun buildSummaryReportText(
    todayProfit: Double,
    todayVolume: Double,
    todayCount: Int,
    todayExpenses: Double,
    language: AppLanguage
): String {
    val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    return """
        *Shahzad Shop Manager - Daily Summary*
        Date: $date
        ----------------------------------
        Today's Transactions: $todayCount
        Total Volume: ${AppStrings.formatPkr(todayVolume, language)}
        Today's Expenses: ${AppStrings.formatPkr(todayExpenses, language)}
        *Net Daily Profit: ${AppStrings.formatPkr(todayProfit, language)}*
        ----------------------------------
        Generated via Shahzad Shop Manager
    """.trimIndent()
}

private fun shareTextReport(context: Context, title: String, content: String, mimeType: String) {
    val sendIntent: Intent = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(Intent.EXTRA_TEXT, content)
        putExtra(Intent.EXTRA_SUBJECT, title)
        type = mimeType
    }
    val shareIntent = Intent.createChooser(sendIntent, title)
    context.startActivity(shareIntent)
}
