package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary emerald green branding for Shahzad Shop Manager
val EmeraldGreenPrimary = Color(0xFF0B6623)
val EmeraldGreenLight = Color(0xFF138808)
val EmeraldGreenDark = Color(0xFF074516)
val EmeraldGreenContainer = Color(0xFFD4EDDA)
val OnEmeraldGreenContainer = Color(0xFF0F3E1B)

// Pakistani Financial Service Colors
val JazzCashRed = Color(0xFFD32F2F)
val JazzCashRedContainer = Color(0xFFFFEBEE)
val EasypaisaGreen = Color(0xFF00A651)
val EasypaisaGreenContainer = Color(0xFFE8F8F0)

val JazzBrandRed = Color(0xFFE50914)
val ZongBrandMagenta = Color(0xFF8E24AA)
val TelenorBrandBlue = Color(0xFF0288D1)
val UfoneBrandOrange = Color(0xFFF57C00)

// Profit & Expense Colors
val ProfitGreen = Color(0xFF2E7D32)
val ProfitGreenContainer = Color(0xFFE8F5E9)
val ExpenseRed = Color(0xFFC62828)
val ExpenseRedContainer = Color(0xFFFFEBEE)

val GoldAccent = Color(0xFFFFB300)
val GoldContainer = Color(0xFFFFF8E1)

// Light Theme Palette
val LightBackground = Color(0xFFF8FAF8)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEFEFEF)
val LightOutline = Color(0xFFD1D5DB)
val LightTextPrimary = Color(0xFF1F2937)
val LightTextSecondary = Color(0xFF6B7280)

// Dark Theme Palette
val DarkBackground = Color(0xFF101913)
val DarkSurface = Color(0xFF16241B)
val DarkSurfaceVariant = Color(0xFF1F3327)
val DarkOutline = Color(0xFF374E3F)
val DarkTextPrimary = Color(0xFFF3F4F6)
val DarkTextSecondary = Color(0xFF9CA3AF)
