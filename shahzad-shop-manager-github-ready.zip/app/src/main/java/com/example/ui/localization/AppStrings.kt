package com.example.ui.localization

import com.example.data.model.AppLanguage
import java.text.NumberFormat
import java.util.Locale

object AppStrings {
    fun formatPkr(amount: Double, language: AppLanguage = AppLanguage.URDU): String {
        val formatter = NumberFormat.getNumberInstance(Locale.US)
        formatter.maximumFractionDigits = 2
        formatter.minimumFractionDigits = 0
        val formattedNumber = formatter.format(amount)
        return if (language == AppLanguage.URDU) {
            "Rs. $formattedNumber"
        } else {
            "PKR $formattedNumber"
        }
    }

    fun get(key: String, language: AppLanguage): String {
        val map = if (language == AppLanguage.URDU) urduStrings else englishStrings
        return map[key] ?: englishStrings[key] ?: key
    }

    // Common Keys
    const val APP_NAME = "app_name"
    const val DASHBOARD = "dashboard"
    const val TRANSACTIONS = "transactions"
    const val BALANCES = "balances"
    const val EXPENSES = "expenses"
    const val CLOSING = "closing"
    const val REPORTS = "reports"
    const val SETTINGS = "settings"

    const val CASH_IN_HAND = "cash_in_hand"
    const val JAZZCASH_BAL = "jazzcash_bal"
    const val EASYPAISA_BAL = "easypaisa_bal"
    const val JAZZ_LOAD_BAL = "jazz_load_bal"
    const val ZONG_LOAD_BAL = "zong_load_bal"
    const val TELENOR_LOAD_BAL = "telenor_load_bal"
    const val UFONE_LOAD_BAL = "ufone_load_bal"

    const val TODAY_TRANSACTIONS = "today_transactions"
    const val TODAY_PROFIT = "today_profit"
    const val TODAY_EXPENSES = "today_expenses"
    const val TODAY_VOLUME = "today_volume"

    const val NEW_TRANSACTION = "new_transaction"
    const val QUICK_ACTIONS = "quick_actions"
    const val CASH_IN = "cash_in"
    const val CASH_OUT = "cash_out"
    const val BILL_PAYMENT = "bill_payment"
    const val MOBILE_LOAD = "mobile_load"
    const val ADD_EXPENSE = "add_expense"
    const val ADJUST_BALANCE = "adjust_balance"
    const val DAILY_CLOSING_BTN = "daily_closing_btn"

    const val AMOUNT = "amount"
    const val SERVICE = "service"
    const val TYPE = "type"
    const val CUSTOMER_NUMBER = "customer_number"
    const val SERVICE_FEE = "service_fee"
    const val COMMISSION = "commission"
    const val NOTES = "notes"
    const val SAVE = "save"
    const val CANCEL = "cancel"
    const val DELETE = "delete"
    const val CONFIRM = "confirm"
    const val SEARCH = "search"
    const val ALL = "all"
    const val FILTER = "filter"

    const val PROFIT_BREAKDOWN = "profit_breakdown"
    const val DAILY_PROFIT = "daily_profit"
    const val WEEKLY_PROFIT = "weekly_profit"
    const val MONTHLY_PROFIT = "monthly_profit"
    const val TOTAL_PROFIT = "total_profit"

    const val EXPORT_EXCEL = "export_excel"
    const val SHARE_SUMMARY = "share_summary"
    const val AUDIT_HISTORY = "audit_history"
    const val PIN_LOCK = "pin_lock"
    const val BACKUP_RESTORE = "backup_restore"
    const val SECURITY_NOTICE = "security_notice"

    private val englishStrings = mapOf(
        APP_NAME to "Shahzad Shop Manager",
        DASHBOARD to "Dashboard",
        TRANSACTIONS to "Transactions",
        BALANCES to "Balances",
        EXPENSES to "Expenses",
        CLOSING to "Daily Closing",
        REPORTS to "Reports",
        SETTINGS to "Settings",

        CASH_IN_HAND to "Cash in Hand",
        JAZZCASH_BAL to "JazzCash Balance",
        EASYPAISA_BAL to "Easypaisa Balance",
        JAZZ_LOAD_BAL to "Jazz Load",
        ZONG_LOAD_BAL to "Zong Load",
        TELENOR_LOAD_BAL to "Telenor Load",
        UFONE_LOAD_BAL to "Ufone Load",

        TODAY_TRANSACTIONS to "Today's Transactions",
        TODAY_PROFIT to "Today's Total Profit",
        TODAY_EXPENSES to "Today's Expenses",
        TODAY_VOLUME to "Today's Total Volume",

        NEW_TRANSACTION to "New Transaction",
        QUICK_ACTIONS to "Quick Actions",
        CASH_IN to "Cash In",
        CASH_OUT to "Cash Out",
        BILL_PAYMENT to "Bill Payment",
        MOBILE_LOAD to "Mobile Load",
        ADD_EXPENSE to "Add Expense",
        ADJUST_BALANCE to "Adjust Balance",
        DAILY_CLOSING_BTN to "Daily Closing",

        AMOUNT to "Amount (PKR)",
        SERVICE to "Service",
        TYPE to "Transaction Type",
        CUSTOMER_NUMBER to "Customer Mobile Number (Optional)",
        SERVICE_FEE to "Customer Service Fee (PKR)",
        COMMISSION to "Agent Commission (PKR)",
        NOTES to "Notes / Remarks (Optional)",
        SAVE to "Save Transaction",
        CANCEL to "Cancel",
        DELETE to "Delete",
        CONFIRM to "Confirm",
        SEARCH to "Search by mobile / note...",
        ALL to "All",
        FILTER to "Filter",

        PROFIT_BREAKDOWN to "Profit Management",
        DAILY_PROFIT to "Daily Profit",
        WEEKLY_PROFIT to "Weekly Profit",
        MONTHLY_PROFIT to "Monthly Profit",
        TOTAL_PROFIT to "All-Time Profit",

        EXPORT_EXCEL to "Export to Excel / CSV",
        SHARE_SUMMARY to "Share Report",
        AUDIT_HISTORY to "Audit History",
        PIN_LOCK to "App PIN Lock",
        BACKUP_RESTORE to "Backup & Restore Database",
        SECURITY_NOTICE to "Security Notice: This app operates 100% locally on your device. It never asks for or stores JazzCash or Easypaisa account passwords, MPINs, or OTPs."
    )

    private val urduStrings = mapOf(
        APP_NAME to "شہزاد شاپ منیجر",
        DASHBOARD to "ڈیش بورڈ",
        TRANSACTIONS to "لین دین",
        BALANCES to "بیلنس و والٹس",
        EXPENSES to "اخراجات",
        CLOSING to "روزانہ کلوزنگ",
        REPORTS to "رپورٹس",
        SETTINGS to "سیٹنگز",

        CASH_IN_HAND to "نقد رقم (کیش ان ہینڈ)",
        JAZZCASH_BAL to "جاز کیش بیلنس",
        EASYPAISA_BAL to "ایزی پیسہ بیلنس",
        JAZZ_LOAD_BAL to "جاز لوڈ بیلنس",
        ZONG_LOAD_BAL to "زونگ لوڈ بیلنس",
        TELENOR_LOAD_BAL to "ٹیلی نار لوڈ بیلنس",
        UFONE_LOAD_BAL to "یوفون لوڈ بیلنس",

        TODAY_TRANSACTIONS to "آج کے کل سودے (لین دین)",
        TODAY_PROFIT to "آج کا کل منافع",
        TODAY_EXPENSES to "آج کے کل اخراجات",
        TODAY_VOLUME to "آج کا کل کاروبار",

        NEW_TRANSACTION to "نیا اندراج / سودا",
        QUICK_ACTIONS to "فوری کارروائی",
        CASH_IN to "کیش اِن (جمع)",
        CASH_OUT to "کیش آؤٹ (نکلوائی)",
        BILL_PAYMENT to "بل ادائیگی",
        MOBILE_LOAD to "موبائل ایزی لوڈ",
        ADD_EXPENSE to "خرچہ درج کریں",
        ADJUST_BALANCE to "بیلنس سیٹ کریں",
        DAILY_CLOSING_BTN to "روزانہ کلوزنگ",

        AMOUNT to "رقم (روپے)",
        SERVICE to "سروس منتخب کریں",
        TYPE to "لین دین کی قسم",
        CUSTOMER_NUMBER to "کسٹمر موبائل نمبر (اختیاری)",
        SERVICE_FEE to "وصول شدہ سروس فیس (روپے)",
        COMMISSION to "کمپنی کمیشن (روپے)",
        NOTES to "تفصیل / ریمارکس (اختیاری)",
        SAVE to "محفوظ کریں",
        CANCEL to "منسوخ",
        DELETE to "حذف کریں",
        CONFIRM to "تصدیق کریں",
        SEARCH to "موبائل نمبر یا تفصیل تلاش کریں...",
        ALL to "تمام",
        FILTER to "فلٹر",

        PROFIT_BREAKDOWN to "منافع کا مکمل حساب",
        DAILY_PROFIT to "آج کا منافع",
        WEEKLY_PROFIT to "ہفتہ وار منافع",
        MONTHLY_PROFIT to "ماہانہ منافع",
        TOTAL_PROFIT to "کل مجموعی منافع",

        EXPORT_EXCEL to "ایکسل / سی ایس وی ایکسپورٹ",
        SHARE_SUMMARY to "رپورٹ شیئر کریں",
        AUDIT_HISTORY to "آڈٹ ہسٹری",
        PIN_LOCK to "ایپ پن لاک سیکیورٹی",
        BACKUP_RESTORE to "بیک اپ اور بحالی (ریسٹور)",
        SECURITY_NOTICE to "حفاظتی انتباہ: یہ ایپ سو فیصد آپ کے فون میں محفوظ کام کرتی ہے۔ یہ جاز کیش یا ایزی پیسہ کا پن، پاسورڈ یا او ٹی پی کبھی نہیں مانگتی اور نہ ہی محفوظ کرتی ہے۔"
    )
}
