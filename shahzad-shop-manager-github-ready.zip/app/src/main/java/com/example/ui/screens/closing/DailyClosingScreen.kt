package com.example.ui.screens.closing

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.BalanceAccount
import com.example.data.model.DailyClosingEntity
import com.example.ui.localization.AppStrings
import com.example.ui.theme.EasypaisaGreen
import com.example.ui.theme.EmeraldGreenPrimary
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.JazzBrandRed
import com.example.ui.theme.JazzCashRed
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.TelenorBrandBlue
import com.example.ui.theme.UfoneBrandOrange
import com.example.ui.theme.ZongBrandMagenta
import com.example.viewmodel.ShopViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DailyClosingScreen(viewModel: ShopViewModel) {
    val language by viewModel.language.collectAsState()
    val balanceMap by viewModel.balanceMap.collectAsState()
    val todayVolume by viewModel.todayVolume.collectAsState()
    val todayCount by viewModel.todayCount.collectAsState()
    val todayProfit by viewModel.todayNetProfit.collectAsState()
    val todayExpenses by viewModel.todayExpensesTotal.collectAsState()
    val allClosings by viewModel.allClosings.collectAsState()

    var closingNotes by remember { mutableStateOf("") }
    var closingSavedSuccess by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val cashInHand = balanceMap[BalanceAccount.CASH_IN_HAND.key] ?: 0.0
    val jazzCashBal = balanceMap[BalanceAccount.JAZZCASH.key] ?: 0.0
    val easypaisaBal = balanceMap[BalanceAccount.EASYPAISA.key] ?: 0.0
    val jazzLoadBal = balanceMap[BalanceAccount.JAZZ_LOAD.key] ?: 0.0
    val zongLoadBal = balanceMap[BalanceAccount.ZONG_LOAD.key] ?: 0.0
    val telenorLoadBal = balanceMap[BalanceAccount.TELENOR_LOAD.key] ?: 0.0
    val ufoneLoadBal = balanceMap[BalanceAccount.UFONE_LOAD.key] ?: 0.0

    val dateFormat = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault())
    val todayPretty = dateFormat.format(Date())

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.EventNote,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = AppStrings.get(AppStrings.CLOSING, language),
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = todayPretty,
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                }
            }

            // Current Day Summary Card to be closed
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = if (language == AppLanguage.URDU) "آج کے دن کا مکمل خلاصہ" else "End-of-Day Financial Summary",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        ClosingSummaryRow("Cash in Hand / نقد کیش", AppStrings.formatPkr(cashInHand, language), EmeraldGreenPrimary)
                        ClosingSummaryRow("JazzCash Balance / جاز کیش", AppStrings.formatPkr(jazzCashBal, language), JazzCashRed)
                        ClosingSummaryRow("Easypaisa Balance / ایزی پیسہ", AppStrings.formatPkr(easypaisaBal, language), EasypaisaGreen)
                        ClosingSummaryRow("Jazz Load / جاز لوڈ", AppStrings.formatPkr(jazzLoadBal, language), JazzBrandRed)
                        ClosingSummaryRow("Zong Load / زونگ لوڈ", AppStrings.formatPkr(zongLoadBal, language), ZongBrandMagenta)
                        ClosingSummaryRow("Telenor Load / ٹیلی نار", AppStrings.formatPkr(telenorLoadBal, language), TelenorBrandBlue)
                        ClosingSummaryRow("Ufone Load / یوفون لوڈ", AppStrings.formatPkr(ufoneLoadBal, language), UfoneBrandOrange)

                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 10.dp),
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                        )

                        ClosingSummaryRow(
                            if (language == AppLanguage.URDU) "آج کا کل کاروبار (حجم)" else "Today's Total Volume",
                            "$todayCount txs (${AppStrings.formatPkr(todayVolume, language)})",
                            MaterialTheme.colorScheme.onSurface
                        )
                        ClosingSummaryRow(
                            if (language == AppLanguage.URDU) "آج کے اخراجات" else "Today's Expenses",
                            "-${AppStrings.formatPkr(todayExpenses, language)}",
                            ExpenseRed
                        )
                        ClosingSummaryRow(
                            if (language == AppLanguage.URDU) "آج کا خالص منافع" else "Today's Net Profit",
                            "+${AppStrings.formatPkr(todayProfit, language)}",
                            ProfitGreen,
                            isBold = true
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedTextField(
                            value = closingNotes,
                            onValueChange = { closingNotes = it },
                            label = { Text(if (language == AppLanguage.URDU) "کلوزنگ ریمارکس / نوٹ (اختیاری)" else "Closing Notes / Remarks (Optional)") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_closing_notes"),
                            maxLines = 3
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                viewModel.performDailyClosing(closingNotes) {
                                    closingSavedSuccess = true
                                    scope.launch {
                                        snackbarHostState.showSnackbar(
                                            if (language == AppLanguage.URDU)
                                                "آج کا دن کامیابی سے کلوز ہو گیا اور بیلنس اگلے دن کے لیے کیری فارورڈ کر دیا گیا!"
                                            else
                                                "Daily closing saved successfully! Balances carried forward to opening."
                                        )
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("btn_save_daily_closing"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (language == AppLanguage.URDU) "آج کی کلوزنگ محفوظ کریں" else "Save Daily Closing Report",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Previous Daily Closings History
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (language == AppLanguage.URDU) "پچھلی کلوزنگز کی تاریخ" else "Past Daily Closings History",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }

            if (allClosings.isEmpty()) {
                item {
                    Text(
                        text = if (language == AppLanguage.URDU) "ابھی تک کوئی سابقہ کلوزنگ محفوظ نہیں ہوئی" else "No previous closings recorded yet.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                }
            } else {
                items(allClosings, key = { it.dateString }) { closing ->
                    PastClosingCard(closing = closing, language = language)
                }
            }

            item {
                Spacer(modifier = Modifier.height(30.dp))
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
fun ClosingSummaryRow(
    label: String,
    value: String,
    color: Color,
    isBold: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal
            )
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(
                color = color,
                fontWeight = if (isBold) FontWeight.ExtraBold else FontWeight.SemiBold
            )
        )
    }
}

@Composable
fun PastClosingCard(
    closing: DailyClosingEntity,
    language: AppLanguage
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = closing.dateString,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Profit: +${AppStrings.formatPkr(closing.netDailyProfit, language)}",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = ProfitGreen,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Closing Cash: ${AppStrings.formatPkr(closing.cashInHand, language)} | Txs: ${closing.totalTransactionsCount}",
                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
            )
            Text(
                text = "JazzCash: ${AppStrings.formatPkr(closing.jazzCashBalance, language)} | Easypaisa: ${AppStrings.formatPkr(closing.easypaisaBalance, language)}",
                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
            )
            if (!closing.notes.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Notes: ${closing.notes}",
                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            }
        }
    }
}
