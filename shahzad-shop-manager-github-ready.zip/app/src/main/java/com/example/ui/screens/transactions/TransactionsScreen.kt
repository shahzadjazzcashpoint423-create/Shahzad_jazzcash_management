package com.example.ui.screens.transactions

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.ServiceType
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.localization.AppStrings
import com.example.ui.theme.EasypaisaGreen
import com.example.ui.theme.JazzBrandRed
import com.example.ui.theme.JazzCashRed
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.TelenorBrandBlue
import com.example.ui.theme.UfoneBrandOrange
import com.example.ui.theme.ZongBrandMagenta
import com.example.viewmodel.ShopViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TransactionsScreen(viewModel: ShopViewModel) {
    val language by viewModel.language.collectAsState()
    val allTransactions by viewModel.allTransactions.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedServiceFilter by remember { mutableStateOf<String?>(null) } // null = All
    var showAddDialog by remember { mutableStateOf(false) }
    var txToDelete by remember { mutableStateOf<TransactionEntity?>(null) }

    val filteredTransactions = allTransactions.filter { tx ->
        val matchesSearch = searchQuery.isBlank() ||
                (tx.customerNumber?.contains(searchQuery, ignoreCase = true) == true) ||
                (tx.notes?.contains(searchQuery, ignoreCase = true) == true) ||
                tx.amount.toString().contains(searchQuery)

        val matchesService = selectedServiceFilter == null || tx.service == selectedServiceFilter
        matchesSearch && matchesService
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_add_transaction")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Transaction")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text(AppStrings.get(AppStrings.SEARCH, language)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_search_tx"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Service Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        label = AppStrings.get(AppStrings.ALL, language),
                        isSelected = selectedServiceFilter == null,
                        onClick = { selectedServiceFilter = null },
                        testTag = "filter_service_all"
                    )
                }
                items(ServiceType.entries) { s ->
                    val isSelected = selectedServiceFilter == s.code
                    FilterChip(
                        label = if (language == AppLanguage.URDU) s.titleUr else s.titleEn,
                        isSelected = isSelected,
                        onClick = { selectedServiceFilter = s.code },
                        testTag = "filter_service_${s.code}"
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Count & Volume Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${filteredTransactions.size} ${if (language == AppLanguage.URDU) "اندراجات" else "entries"}",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
                val totalVol = filteredTransactions.sumOf { it.amount }
                val totalProf = filteredTransactions.sumOf { it.netProfit }
                Text(
                    text = "Vol: ${AppStrings.formatPkr(totalVol, language)} | Profit: +${AppStrings.formatPkr(totalProf, language)}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (filteredTransactions.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.ReceiptLong,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (language == AppLanguage.URDU) "کوئی لین دین نہیں ملا" else "No transactions found",
                            style = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredTransactions, key = { it.id }) { tx ->
                        TransactionDetailCard(
                            tx = tx,
                            language = language,
                            onDelete = { txToDelete = tx }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(80.dp)) // padding for FAB
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddTransactionDialog(
            language = language,
            onDismiss = { showAddDialog = false },
            onSave = { service, type, amount, fee, commission, customer, notes ->
                viewModel.addTransaction(
                    service = service,
                    transactionType = type,
                    amount = amount,
                    serviceFee = fee,
                    commission = commission,
                    customerNumber = customer,
                    notes = notes,
                    onDone = { showAddDialog = false }
                )
            }
        )
    }

    if (txToDelete != null) {
        val tx = txToDelete!!
        ConfirmDeleteDialog(
            title = if (language == AppLanguage.URDU) "سودا حذف کریں؟" else "Delete Transaction?",
            message = if (language == AppLanguage.URDU)
                "کیا آپ واقعی ${AppStrings.formatPkr(tx.amount, language)} کا یہ سودا حذف کرنا چاہتے ہیں؟ اس سے متعلقہ والٹ اور کیش بیلنس خودکار طور پر درست کر دیا جائے گا۔"
            else
                "Are you sure you want to delete this transaction of ${AppStrings.formatPkr(tx.amount, language)}? All associated balances will be automatically reverted.",
            language = language,
            onConfirm = {
                viewModel.deleteTransaction(tx)
                txToDelete = null
            },
            onDismiss = { txToDelete = null }
        )
    }
}

@Composable
fun FilterChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .testTag(testTag),
        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(8.dp)
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
            )
        )
    }
}

@Composable
fun TransactionDetailCard(
    tx: TransactionEntity,
    language: AppLanguage,
    onDelete: () -> Unit
) {
    val sType = ServiceType.fromCode(tx.service)
    val tType = TransactionType.fromCode(tx.transactionType)
    val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
    val formattedTime = timeFormat.format(Date(tx.timestamp))

    val serviceColor = when (sType) {
        ServiceType.JAZZCASH -> JazzCashRed
        ServiceType.EASYPAISA -> EasypaisaGreen
        ServiceType.JAZZ_LOAD -> JazzBrandRed
        ServiceType.ZONG_LOAD -> ZongBrandMagenta
        ServiceType.TELENOR_LOAD -> TelenorBrandBlue
        ServiceType.UFONE_LOAD -> UfoneBrandOrange
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(serviceColor.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (tType) {
                                TransactionType.CASH_IN -> Icons.Default.ArrowDownward
                                TransactionType.CASH_OUT -> Icons.Default.ArrowUpward
                                TransactionType.BILL_PAYMENT -> Icons.Default.Receipt
                                TransactionType.MOBILE_LOAD -> Icons.Default.PhoneAndroid
                                else -> Icons.Default.ReceiptLong
                            },
                            contentDescription = null,
                            tint = serviceColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = if (language == AppLanguage.URDU) sType.titleUr else sType.titleEn,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        )
                        Text(
                            text = "${if (language == AppLanguage.URDU) tType.titleUr else tType.titleEn} • $formattedTime",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp
                            )
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = AppStrings.formatPkr(tx.amount, language),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        if (tx.netProfit > 0) {
                            Text(
                                text = "+${AppStrings.formatPkr(tx.netProfit, language)} profit",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = ProfitGreen,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("delete_tx_${tx.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Bottom detail strip if customer / fee / notes present
            if (!tx.customerNumber.isNullOrBlank() || tx.serviceFee > 0 || tx.commission > 0 || !tx.notes.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    if (!tx.customerNumber.isNullOrBlank()) {
                        Text(
                            text = "Customer: ${tx.customerNumber}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                    if (tx.serviceFee > 0 || tx.commission > 0) {
                        Text(
                            text = "Fee: ${AppStrings.formatPkr(tx.serviceFee, language)} | Comm: ${AppStrings.formatPkr(tx.commission, language)}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }

                if (!tx.notes.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Notes: ${tx.notes}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                    )
                }
            }
        }
    }
}
