package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.DailyClosingEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DailyClosingDao {
    @Query("SELECT * FROM daily_closings ORDER BY closingTimestamp DESC")
    fun getAllClosings(): Flow<List<DailyClosingEntity>>

    @Query("SELECT * FROM daily_closings WHERE dateString = :dateString")
    suspend fun getClosingForDate(dateString: String): DailyClosingEntity?

    @Query("SELECT * FROM daily_closings WHERE dateString = :dateString")
    fun observeClosingForDate(dateString: String): Flow<DailyClosingEntity?>

    @Query("SELECT * FROM daily_closings ORDER BY closingTimestamp DESC LIMIT 1")
    suspend fun getLatestClosing(): DailyClosingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClosing(closing: DailyClosingEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(closings: List<DailyClosingEntity>)

    @Update
    suspend fun updateClosing(closing: DailyClosingEntity)

    @Delete
    suspend fun deleteClosing(closing: DailyClosingEntity)

    @Query("SELECT * FROM daily_closings ORDER BY closingTimestamp DESC")
    suspend fun getAllClosingsSync(): List<DailyClosingEntity>

    @Query("DELETE FROM daily_closings")
    suspend fun deleteAll()
}
