package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.BalanceAccountEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BalanceAccountDao {
    @Query("SELECT * FROM balance_accounts")
    fun getAllAccounts(): Flow<List<BalanceAccountEntity>>

    @Query("SELECT * FROM balance_accounts")
    suspend fun getAllAccountsSync(): List<BalanceAccountEntity>

    @Query("SELECT * FROM balance_accounts WHERE accountKey = :key")
    fun getAccount(key: String): Flow<BalanceAccountEntity?>

    @Query("SELECT * FROM balance_accounts WHERE accountKey = :key")
    suspend fun getAccountSync(key: String): BalanceAccountEntity?

    @Query("SELECT currentBalance FROM balance_accounts WHERE accountKey = :key")
    suspend fun getBalanceValue(key: String): Double?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(account: BalanceAccountEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(accounts: List<BalanceAccountEntity>)

    @Update
    suspend fun update(account: BalanceAccountEntity)

    @Query("UPDATE balance_accounts SET currentBalance = currentBalance + :delta, lastUpdated = :now WHERE accountKey = :key")
    suspend fun updateBalanceByDelta(key: String, delta: Double, now: Long = System.currentTimeMillis())

    @Query("UPDATE balance_accounts SET currentBalance = :newBalance, lastUpdated = :now WHERE accountKey = :key")
    suspend fun setBalance(key: String, newBalance: Double, now: Long = System.currentTimeMillis())

    @Query("DELETE FROM balance_accounts")
    suspend fun deleteAll()
}
