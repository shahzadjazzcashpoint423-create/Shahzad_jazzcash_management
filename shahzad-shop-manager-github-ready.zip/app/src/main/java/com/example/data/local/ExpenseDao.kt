package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.ExpenseEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ExpenseDao {
    @Query("SELECT * FROM expenses ORDER BY timestamp DESC")
    fun getAllExpenses(): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses WHERE dateString = :dateString ORDER BY timestamp DESC")
    fun getExpensesByDate(dateString: String): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses WHERE dateString = :dateString")
    suspend fun getExpensesByDateSync(dateString: String): List<ExpenseEntity>

    @Query("SELECT * FROM expenses WHERE timestamp BETWEEN :startTimestamp AND :endTimestamp ORDER BY timestamp DESC")
    fun getExpensesBetween(startTimestamp: Long, endTimestamp: Long): Flow<List<ExpenseEntity>>

    @Query("SELECT SUM(amount) FROM expenses WHERE dateString = :dateString")
    fun getTodayTotalExpenses(dateString: String): Flow<Double?>

    @Query("SELECT SUM(amount) FROM expenses WHERE timestamp BETWEEN :start AND :end")
    fun getExpensesTotalBetween(start: Long, end: Long): Flow<Double?>

    @Query("SELECT SUM(amount) FROM expenses")
    fun getAllTimeTotalExpenses(): Flow<Double?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: ExpenseEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(expenses: List<ExpenseEntity>)

    @Update
    suspend fun updateExpense(expense: ExpenseEntity)

    @Delete
    suspend fun deleteExpense(expense: ExpenseEntity)

    @Query("DELETE FROM expenses WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM expenses ORDER BY timestamp DESC")
    suspend fun getAllExpensesSync(): List<ExpenseEntity>

    @Query("DELETE FROM expenses")
    suspend fun deleteAll()
}
