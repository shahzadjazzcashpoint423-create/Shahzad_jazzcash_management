package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.model.BackupBalance
import com.example.data.model.BackupDailyClosing
import com.example.data.model.BackupExpense
import com.example.data.model.BackupTransaction
import com.example.data.model.BalanceAccount
import com.example.data.model.BalanceAccountEntity
import com.example.data.model.DailyClosingEntity
import com.example.data.model.DatabaseBackup
import com.example.data.model.ExpenseEntity
import com.example.data.model.ServiceType
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ShopRepository(private val database: AppDatabase) {
    private val transactionDao = database.transactionDao()
    private val expenseDao = database.expenseDao()
    private val balanceDao = database.balanceAccountDao()
    private val closingDao = database.dailyClosingDao()

    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    private val backupAdapter = moshi.adapter(DatabaseBackup::class.java)

    val allTransactions: Flow<List<TransactionEntity>> = transactionDao.getAllTransactions()
    val allExpenses: Flow<List<ExpenseEntity>> = expenseDao.getAllExpenses()
    val allAccounts: Flow<List<BalanceAccountEntity>> = balanceDao.getAllAccounts()
    val allClosings: Flow<List<DailyClosingEntity>> = closingDao.getAllClosings()

    fun getTransactionsByDate(dateString: String): Flow<List<TransactionEntity>> =
        transactionDao.getTransactionsByDate(dateString)

    fun getExpensesByDate(dateString: String): Flow<List<ExpenseEntity>> =
        expenseDao.getExpensesByDate(dateString)

    fun getTodayVolume(dateString: String): Flow<Double?> =
        transactionDao.getTodayTotalVolume(dateString)

    fun getTodayCount(dateString: String): Flow<Int> =
        transactionDao.getTodayTotalCount(dateString)

    fun getTodayProfitFromTransactions(dateString: String): Flow<Double?> =
        transactionDao.getTodayProfitFromTransactions(dateString)

    fun getTodayExpenses(dateString: String): Flow<Double?> =
        expenseDao.getTodayTotalExpenses(dateString)

    fun getProfitBetween(start: Long, end: Long): Flow<Double?> =
        transactionDao.getProfitBetween(start, end)

    fun getExpensesBetween(start: Long, end: Long): Flow<Double?> =
        expenseDao.getExpensesTotalBetween(start, end)

    fun getAllTimeProfit(): Flow<Double?> =
        transactionDao.getAllTimeProfitFromTransactions()

    fun getAllTimeExpenses(): Flow<Double?> =
        expenseDao.getAllTimeTotalExpenses()

    suspend fun initializeDefaultAccountsIfNeeded() {
        val existing = balanceDao.getAllAccountsSync()
        if (existing.isEmpty()) {
            val initialAccounts = BalanceAccount.entries.map {
                BalanceAccountEntity(accountKey = it.key, currentBalance = 0.0)
            }
            balanceDao.insertAll(initialAccounts)
        } else {
            // Ensure any missing account is inserted
            val existingKeys = existing.map { it.accountKey }.toSet()
            val missing = BalanceAccount.entries
                .filter { it.key !in existingKeys }
                .map { BalanceAccountEntity(accountKey = it.key, currentBalance = 0.0) }
            if (missing.isNotEmpty()) {
                balanceDao.insertAll(missing)
            }
        }
    }

    suspend fun addTransaction(transaction: TransactionEntity): Long {
        val id = transactionDao.insertTransaction(transaction)
        val sType = ServiceType.fromCode(transaction.service)
        val tType = TransactionType.fromCode(transaction.transactionType)
        val amount = transaction.amount
        val fee = transaction.serviceFee
        val commission = transaction.commission

        val targetAccountKey = when (sType) {
            ServiceType.JAZZCASH -> BalanceAccount.JAZZCASH.key
            ServiceType.EASYPAISA -> BalanceAccount.EASYPAISA.key
            ServiceType.JAZZ_LOAD -> BalanceAccount.JAZZ_LOAD.key
            ServiceType.ZONG_LOAD -> BalanceAccount.ZONG_LOAD.key
            ServiceType.TELENOR_LOAD -> BalanceAccount.TELENOR_LOAD.key
            ServiceType.UFONE_LOAD -> BalanceAccount.UFONE_LOAD.key
        }

        when (tType) {
            TransactionType.CASH_IN -> {
                // Customer deposits cash: physical cash increases by (amount + fee)
                // Wallet balance decreases by amount, gains commission if applicable
                balanceDao.updateBalanceByDelta(BalanceAccount.CASH_IN_HAND.key, amount + fee)
                balanceDao.updateBalanceByDelta(targetAccountKey, -amount + commission)
            }
            TransactionType.CASH_OUT -> {
                // Customer withdraws cash: physical cash decreases by amount, gains fee
                // Wallet balance increases by amount + commission
                balanceDao.updateBalanceByDelta(BalanceAccount.CASH_IN_HAND.key, -amount + fee)
                balanceDao.updateBalanceByDelta(targetAccountKey, amount + commission)
            }
            TransactionType.BILL_PAYMENT -> {
                // Customer pays bill: physical cash increases by amount + fee
                // Wallet balance decreases by amount, gains commission
                balanceDao.updateBalanceByDelta(BalanceAccount.CASH_IN_HAND.key, amount + fee)
                balanceDao.updateBalanceByDelta(targetAccountKey, -amount + commission)
            }
            TransactionType.MOBILE_LOAD -> {
                // Mobile load: physical cash increases by amount + fee
                // Load SIM balance decreases by amount, gains commission
                balanceDao.updateBalanceByDelta(BalanceAccount.CASH_IN_HAND.key, amount + fee)
                balanceDao.updateBalanceByDelta(targetAccountKey, -amount + commission)
            }
            TransactionType.SERVICE_FEE -> {
                // Standalone service fee collected in cash
                balanceDao.updateBalanceByDelta(BalanceAccount.CASH_IN_HAND.key, fee)
            }
            TransactionType.ADJUSTMENT -> {
                // Handled directly via adjustAccountBalance
            }
        }

        return id
    }

    suspend fun deleteTransaction(transaction: TransactionEntity) {
        val sType = ServiceType.fromCode(transaction.service)
        val tType = TransactionType.fromCode(transaction.transactionType)
        val amount = transaction.amount
        val fee = transaction.serviceFee
        val commission = transaction.commission

        val targetAccountKey = when (sType) {
            ServiceType.JAZZCASH -> BalanceAccount.JAZZCASH.key
            ServiceType.EASYPAISA -> BalanceAccount.EASYPAISA.key
            ServiceType.JAZZ_LOAD -> BalanceAccount.JAZZ_LOAD.key
            ServiceType.ZONG_LOAD -> BalanceAccount.ZONG_LOAD.key
            ServiceType.TELENOR_LOAD -> BalanceAccount.TELENOR_LOAD.key
            ServiceType.UFONE_LOAD -> BalanceAccount.UFONE_LOAD.key
        }

        // Reverse the mutations
        when (tType) {
            TransactionType.CASH_IN -> {
                balanceDao.updateBalanceByDelta(BalanceAccount.CASH_IN_HAND.key, -(amount + fee))
                balanceDao.updateBalanceByDelta(targetAccountKey, amount - commission)
            }
            TransactionType.CASH_OUT -> {
                balanceDao.updateBalanceByDelta(BalanceAccount.CASH_IN_HAND.key, amount - fee)
                balanceDao.updateBalanceByDelta(targetAccountKey, -(amount + commission))
            }
            TransactionType.BILL_PAYMENT -> {
                balanceDao.updateBalanceByDelta(BalanceAccount.CASH_IN_HAND.key, -(amount + fee))
                balanceDao.updateBalanceByDelta(targetAccountKey, amount - commission)
            }
            TransactionType.MOBILE_LOAD -> {
                balanceDao.updateBalanceByDelta(BalanceAccount.CASH_IN_HAND.key, -(amount + fee))
                balanceDao.updateBalanceByDelta(targetAccountKey, amount - commission)
            }
            TransactionType.SERVICE_FEE -> {
                balanceDao.updateBalanceByDelta(BalanceAccount.CASH_IN_HAND.key, -fee)
            }
            TransactionType.ADJUSTMENT -> {
                // Manual adjustments deletion
            }
        }

        transactionDao.deleteTransaction(transaction)
    }

    suspend fun addExpense(expense: ExpenseEntity): Long {
        val id = expenseDao.insertExpense(expense)
        if (expense.paidFromAccount == BalanceAccount.CASH_IN_HAND.key) {
            balanceDao.updateBalanceByDelta(BalanceAccount.CASH_IN_HAND.key, -expense.amount)
        }
        return id
    }

    suspend fun deleteExpense(expense: ExpenseEntity) {
        if (expense.paidFromAccount == BalanceAccount.CASH_IN_HAND.key) {
            balanceDao.updateBalanceByDelta(BalanceAccount.CASH_IN_HAND.key, expense.amount)
        }
        expenseDao.deleteExpense(expense)
    }

    suspend fun adjustAccountBalance(
        accountKey: String,
        newBalance: Double,
        reason: String
    ) {
        val current = balanceDao.getBalanceValue(accountKey) ?: 0.0
        val difference = newBalance - current

        balanceDao.setBalance(accountKey, newBalance)

        // Log an audit transaction for transparency
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val todayStr = dateFormat.format(Date())

        val service = when (accountKey) {
            BalanceAccount.JAZZCASH.key -> ServiceType.JAZZCASH.code
            BalanceAccount.EASYPAISA.key -> ServiceType.EASYPAISA.code
            BalanceAccount.JAZZ_LOAD.key -> ServiceType.JAZZ_LOAD.code
            BalanceAccount.ZONG_LOAD.key -> ServiceType.ZONG_LOAD.code
            BalanceAccount.TELENOR_LOAD.key -> ServiceType.TELENOR_LOAD.code
            BalanceAccount.UFONE_LOAD.key -> ServiceType.UFONE_LOAD.code
            else -> ServiceType.JAZZCASH.code
        }

        transactionDao.insertTransaction(
            TransactionEntity(
                service = service,
                transactionType = TransactionType.ADJUSTMENT.code,
                amount = kotlin.math.abs(difference),
                serviceFee = 0.0,
                commission = 0.0,
                netProfit = 0.0,
                customerNumber = null,
                timestamp = System.currentTimeMillis(),
                dateString = todayStr,
                notes = "Balance adjustment for $accountKey: ${if (difference >= 0) "+$difference" else "$difference"}. Reason: $reason"
            )
        )
    }

    suspend fun performDailyClosing(
        dateString: String,
        notes: String?
    ): DailyClosingEntity {
        val accounts = balanceDao.getAllAccountsSync().associateBy { it.accountKey }
        val cashInHand = accounts[BalanceAccount.CASH_IN_HAND.key]?.currentBalance ?: 0.0
        val jazzCash = accounts[BalanceAccount.JAZZCASH.key]?.currentBalance ?: 0.0
        val easypaisa = accounts[BalanceAccount.EASYPAISA.key]?.currentBalance ?: 0.0
        val jazzLoad = accounts[BalanceAccount.JAZZ_LOAD.key]?.currentBalance ?: 0.0
        val zongLoad = accounts[BalanceAccount.ZONG_LOAD.key]?.currentBalance ?: 0.0
        val telenorLoad = accounts[BalanceAccount.TELENOR_LOAD.key]?.currentBalance ?: 0.0
        val ufoneLoad = accounts[BalanceAccount.UFONE_LOAD.key]?.currentBalance ?: 0.0

        val todayTxs = transactionDao.getTransactionsByDateSync(dateString)
        val todayExps = expenseDao.getExpensesByDateSync(dateString)

        val totalVolume = todayTxs.sumOf { it.amount }
        val totalFees = todayTxs.sumOf { it.serviceFee }
        val totalCommissions = todayTxs.sumOf { it.commission }
        val totalExpenses = todayExps.sumOf { it.amount }
        val netProfit = (totalFees + totalCommissions) - totalExpenses

        val closing = DailyClosingEntity(
            dateString = dateString,
            closingTimestamp = System.currentTimeMillis(),
            cashInHand = cashInHand,
            jazzCashBalance = jazzCash,
            easypaisaBalance = easypaisa,
            jazzLoadBalance = jazzLoad,
            zongLoadBalance = zongLoad,
            telenorLoadBalance = telenorLoad,
            ufoneLoadBalance = ufoneLoad,
            totalTransactionsCount = todayTxs.size,
            totalTransactionsVolume = totalVolume,
            totalDayFees = totalFees,
            totalDayCommissions = totalCommissions,
            totalDayExpenses = totalExpenses,
            netDailyProfit = netProfit,
            notes = notes
        )

        closingDao.insertClosing(closing)
        return closing
    }

    suspend fun exportBackupJson(): String {
        val txs = transactionDao.getAllTransactionsSync().map {
            BackupTransaction(
                id = it.id,
                service = it.service,
                transactionType = it.transactionType,
                amount = it.amount,
                serviceFee = it.serviceFee,
                commission = it.commission,
                netProfit = it.netProfit,
                customerNumber = it.customerNumber,
                timestamp = it.timestamp,
                dateString = it.dateString,
                notes = it.notes
            )
        }
        val exps = expenseDao.getAllExpensesSync().map {
            BackupExpense(
                id = it.id,
                category = it.category,
                amount = it.amount,
                description = it.description,
                timestamp = it.timestamp,
                dateString = it.dateString,
                paidFromAccount = it.paidFromAccount
            )
        }
        val balances = balanceDao.getAllAccountsSync().map {
            BackupBalance(
                accountKey = it.accountKey,
                currentBalance = it.currentBalance,
                lastUpdated = it.lastUpdated
            )
        }
        val closings = closingDao.getAllClosingsSync().map {
            BackupDailyClosing(
                dateString = it.dateString,
                closingTimestamp = it.closingTimestamp,
                cashInHand = it.cashInHand,
                jazzCashBalance = it.jazzCashBalance,
                easypaisaBalance = it.easypaisaBalance,
                jazzLoadBalance = it.jazzLoadBalance,
                zongLoadBalance = it.zongLoadBalance,
                telenorLoadBalance = it.telenorLoadBalance,
                ufoneLoadBalance = it.ufoneLoadBalance,
                totalTransactionsCount = it.totalTransactionsCount,
                totalTransactionsVolume = it.totalTransactionsVolume,
                totalDayFees = it.totalDayFees,
                totalDayCommissions = it.totalDayCommissions,
                totalDayExpenses = it.totalDayExpenses,
                netDailyProfit = it.netDailyProfit,
                notes = it.notes
            )
        }

        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val backup = DatabaseBackup(
            exportDate = dateFormat.format(Date()),
            transactions = txs,
            expenses = exps,
            balances = balances,
            dailyClosings = closings
        )

        return backupAdapter.toJson(backup)
    }

    suspend fun importBackupJson(jsonString: String): Boolean {
        return try {
            val backup = backupAdapter.fromJson(jsonString) ?: return false

            // Clear old data
            transactionDao.deleteAll()
            expenseDao.deleteAll()
            balanceDao.deleteAll()
            closingDao.deleteAll()

            // Insert backup data
            val txEntities = backup.transactions.map {
                TransactionEntity(
                    id = it.id,
                    service = it.service,
                    transactionType = it.transactionType,
                    amount = it.amount,
                    serviceFee = it.serviceFee,
                    commission = it.commission,
                    netProfit = it.netProfit,
                    customerNumber = it.customerNumber,
                    timestamp = it.timestamp,
                    dateString = it.dateString,
                    notes = it.notes
                )
            }
            val expEntities = backup.expenses.map {
                ExpenseEntity(
                    id = it.id,
                    category = it.category,
                    amount = it.amount,
                    description = it.description,
                    timestamp = it.timestamp,
                    dateString = it.dateString,
                    paidFromAccount = it.paidFromAccount
                )
            }
            val balanceEntities = backup.balances.map {
                BalanceAccountEntity(
                    accountKey = it.accountKey,
                    currentBalance = it.currentBalance,
                    lastUpdated = it.lastUpdated
                )
            }
            val closingEntities = backup.dailyClosings.map {
                DailyClosingEntity(
                    dateString = it.dateString,
                    closingTimestamp = it.closingTimestamp,
                    cashInHand = it.cashInHand,
                    jazzCashBalance = it.jazzCashBalance,
                    easypaisaBalance = it.easypaisaBalance,
                    jazzLoadBalance = it.jazzLoadBalance,
                    zongLoadBalance = it.zongLoadBalance,
                    telenorLoadBalance = it.telenorLoadBalance,
                    ufoneLoadBalance = it.ufoneLoadBalance,
                    totalTransactionsCount = it.totalTransactionsCount,
                    totalTransactionsVolume = it.totalTransactionsVolume,
                    totalDayFees = it.totalDayFees,
                    totalDayCommissions = it.totalDayCommissions,
                    totalDayExpenses = it.totalDayExpenses,
                    netDailyProfit = it.netDailyProfit,
                    notes = it.notes
                )
            }

            transactionDao.insertAll(txEntities)
            expenseDao.insertAll(expEntities)
            balanceDao.insertAll(balanceEntities)
            closingDao.insertAll(closingEntities)
            true
        } catch (_: Exception) {
            false
        }
    }
}
