package com.example.data.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class DatabaseBackup(
    val exportDate: String,
    val appVersion: String = "1.0",
    val transactions: List<BackupTransaction>,
    val expenses: List<BackupExpense>,
    val balances: List<BackupBalance>,
    val dailyClosings: List<BackupDailyClosing>
)

@JsonClass(generateAdapter = true)
data class BackupTransaction(
    val id: Long,
    val service: String,
    val transactionType: String,
    val amount: Double,
    val serviceFee: Double,
    val commission: Double,
    val netProfit: Double,
    val customerNumber: String?,
    val timestamp: Long,
    val dateString: String,
    val notes: String?
)

@JsonClass(generateAdapter = true)
data class BackupExpense(
    val id: Long,
    val category: String,
    val amount: Double,
    val description: String,
    val timestamp: Long,
    val dateString: String,
    val paidFromAccount: String
)

@JsonClass(generateAdapter = true)
data class BackupBalance(
    val accountKey: String,
    val currentBalance: Double,
    val lastUpdated: Long
)

@JsonClass(generateAdapter = true)
data class BackupDailyClosing(
    val dateString: String,
    val closingTimestamp: Long,
    val cashInHand: Double,
    val jazzCashBalance: Double,
    val easypaisaBalance: Double,
    val jazzLoadBalance: Double,
    val zongLoadBalance: Double,
    val telenorLoadBalance: Double,
    val ufoneLoadBalance: Double,
    val totalTransactionsCount: Int,
    val totalTransactionsVolume: Double,
    val totalDayFees: Double,
    val totalDayCommissions: Double,
    val totalDayExpenses: Double,
    val netDailyProfit: Double,
    val notes: String?
)
