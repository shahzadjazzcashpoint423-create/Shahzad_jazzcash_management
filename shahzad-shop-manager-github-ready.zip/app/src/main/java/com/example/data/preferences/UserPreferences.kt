package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.AppLanguage
import com.example.data.model.ThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class UserPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("shahzad_shop_prefs", Context.MODE_PRIVATE)

    private val _language = MutableStateFlow(getLanguageInternal())
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    private val _themeMode = MutableStateFlow(getThemeModeInternal())
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    private val _isPinEnabled = MutableStateFlow(prefs.getBoolean(KEY_PIN_ENABLED, false))
    val isPinEnabled: StateFlow<Boolean> = _isPinEnabled.asStateFlow()

    private val _shopName = MutableStateFlow(prefs.getString(KEY_SHOP_NAME, "Shahzad Shop") ?: "Shahzad Shop")
    val shopName: StateFlow<String> = _shopName.asStateFlow()

    private fun getLanguageInternal(): AppLanguage {
        val code = prefs.getString(KEY_LANGUAGE, AppLanguage.URDU.code) ?: AppLanguage.URDU.code
        return if (code == AppLanguage.ENGLISH.code) AppLanguage.ENGLISH else AppLanguage.URDU
    }

    private fun getThemeModeInternal(): ThemeMode {
        val name = prefs.getString(KEY_THEME_MODE, ThemeMode.SYSTEM.name) ?: ThemeMode.SYSTEM.name
        return try {
            ThemeMode.valueOf(name)
        } catch (_: Exception) {
            ThemeMode.SYSTEM
        }
    }

    fun setLanguage(lang: AppLanguage) {
        prefs.edit().putString(KEY_LANGUAGE, lang.code).apply()
        _language.value = lang
    }

    fun setThemeMode(mode: ThemeMode) {
        prefs.edit().putString(KEY_THEME_MODE, mode.name).apply()
        _themeMode.value = mode
    }

    fun setPin(pin: String) {
        prefs.edit()
            .putString(KEY_PIN_CODE, pin)
            .putBoolean(KEY_PIN_ENABLED, true)
            .apply()
        _isPinEnabled.value = true
    }

    fun disablePin() {
        prefs.edit()
            .remove(KEY_PIN_CODE)
            .putBoolean(KEY_PIN_ENABLED, false)
            .apply()
        _isPinEnabled.value = false
    }

    fun verifyPin(input: String): Boolean {
        val saved = prefs.getString(KEY_PIN_CODE, null) ?: return true
        return saved == input
    }

    fun hasPinSet(): Boolean {
        return prefs.getString(KEY_PIN_CODE, null) != null
    }

    fun setShopName(name: String) {
        prefs.edit().putString(KEY_SHOP_NAME, name).apply()
        _shopName.value = name
    }

    fun isDatabaseInitialized(): Boolean {
        return prefs.getBoolean(KEY_DB_INIT, false)
    }

    fun setDatabaseInitialized(initialized: Boolean) {
        prefs.edit().putBoolean(KEY_DB_INIT, initialized).apply()
    }

    companion object {
        private const val KEY_LANGUAGE = "key_language"
        private const val KEY_THEME_MODE = "key_theme_mode"
        private const val KEY_PIN_ENABLED = "key_pin_enabled"
        private const val KEY_PIN_CODE = "key_pin_code"
        private const val KEY_SHOP_NAME = "key_shop_name"
        private const val KEY_DB_INIT = "key_db_initialized"
    }
}
