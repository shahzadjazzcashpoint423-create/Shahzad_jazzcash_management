package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "transactions",
    indices = [
        Index(value = ["dateString"]),
        Index(value = ["timestamp"]),
        Index(value = ["service"]),
        Index(value = ["transactionType"])
    ]
)
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val service: String, // JAZZCASH, EASYPAISA, JAZZ_LOAD, ZONG_LOAD, TELENOR_LOAD, UFONE_LOAD
    val transactionType: String, // CASH_IN, CASH_OUT, BILL_PAYMENT, MOBILE_LOAD, SERVICE_FEE, ADJUSTMENT
    val amount: Double,
    val serviceFee: Double = 0.0,
    val commission: Double = 0.0,
    val netProfit: Double = 0.0, // serviceFee + commission
    val customerNumber: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val dateString: String, // "yyyy-MM-dd"
    val notes: String? = null
)

@Entity(
    tableName = "expenses",
    indices = [
        Index(value = ["dateString"]),
        Index(value = ["timestamp"]),
        Index(value = ["category"])
    ]
)
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val category: String, // SHOP, PERSONAL, OTHER
    val amount: Double,
    val description: String,
    val timestamp: Long = System.currentTimeMillis(),
    val dateString: String, // "yyyy-MM-dd"
    val paidFromAccount: String = "CASH_IN_HAND"
)

@Entity(tableName = "balance_accounts")
data class BalanceAccountEntity(
    @PrimaryKey
    val accountKey: String, // BalanceAccount enum key
    val currentBalance: Double = 0.0,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "daily_closings")
data class DailyClosingEntity(
    @PrimaryKey
    val dateString: String, // "yyyy-MM-dd"
    val closingTimestamp: Long = System.currentTimeMillis(),
    val cashInHand: Double,
    val jazzCashBalance: Double,
    val easypaisaBalance: Double,
    val jazzLoadBalance: Double,
    val zongLoadBalance: Double,
    val telenorLoadBalance: Double,
    val ufoneLoadBalance: Double,
    val totalTransactionsCount: Int,
    val totalTransactionsVolume: Double,
    val totalDayFees: Double,
    val totalDayCommissions: Double,
    val totalDayExpenses: Double,
    val netDailyProfit: Double,
    val notes: String? = null
)
