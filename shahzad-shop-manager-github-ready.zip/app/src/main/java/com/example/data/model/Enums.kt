package com.example.data.model

enum class AppLanguage(val code: String, val title: String) {
    ENGLISH("en", "English"),
    URDU("ur", "اردو")
}

enum class ThemeMode(val titleEn: String, val titleUr: String) {
    SYSTEM("System Default", "سسٹم کے مطابق"),
    LIGHT("Light Mode", "لائٹ موڈ"),
    DARK("Dark Mode", "ڈارک موڈ")
}

enum class ServiceType(val code: String, val titleEn: String, val titleUr: String) {
    JAZZCASH("JAZZCASH", "JazzCash", "جاز کیش"),
    EASYPAISA("EASYPAISA", "Easypaisa", "ایزی پیسہ"),
    JAZZ_LOAD("JAZZ_LOAD", "Jazz Load", "جاز لوڈ"),
    ZONG_LOAD("ZONG_LOAD", "Zong Load", "زونگ لوڈ"),
    TELENOR_LOAD("TELENOR_LOAD", "Telenor Load", "ٹیلی نار لوڈ"),
    UFONE_LOAD("UFONE_LOAD", "Ufone Load", "یوفون لوڈ");

    companion object {
        fun fromCode(code: String): ServiceType {
            return entries.firstOrNull { it.code == code } ?: JAZZCASH
        }
    }
}

enum class TransactionType(val code: String, val titleEn: String, val titleUr: String) {
    CASH_IN("CASH_IN", "Cash In", "کیش اِن (رقم جمع)"),
    CASH_OUT("CASH_OUT", "Cash Out", "کیش آؤٹ (رقم نکلوائی)"),
    BILL_PAYMENT("BILL_PAYMENT", "Bill Payment", "یوٹیلٹی بل ادائیگی"),
    MOBILE_LOAD("MOBILE_LOAD", "Mobile Load", "موبائل ایزی لوڈ"),
    SERVICE_FEE("SERVICE_FEE", "Service Fee", "سروس فیس وصولی"),
    ADJUSTMENT("ADJUSTMENT", "Balance Adjustment", "بیلنس ایڈجسٹمنٹ");

    companion object {
        fun fromCode(code: String): TransactionType {
            return entries.firstOrNull { it.code == code } ?: CASH_IN
        }
    }
}

enum class ExpenseCategory(val code: String, val titleEn: String, val titleUr: String) {
    SHOP("SHOP", "Shop Expense", "دکان کا خرچہ"),
    PERSONAL("PERSONAL", "Personal Expense", "ذاتی خرچہ"),
    OTHER("OTHER", "Other Expense", "دیگر اخراجات");

    companion object {
        fun fromCode(code: String): ExpenseCategory {
            return entries.firstOrNull { it.code == code } ?: SHOP
        }
    }
}

enum class BalanceAccount(val key: String, val nameEn: String, val nameUr: String) {
    CASH_IN_HAND("CASH_IN_HAND", "Cash in Hand", "کیش ان ہینڈ (نقد رقم)"),
    JAZZCASH("JAZZCASH", "JazzCash Wallet", "جاز کیش بیلنس"),
    EASYPAISA("EASYPAISA", "Easypaisa Wallet", "ایزی پیسہ بیلنس"),
    JAZZ_LOAD("JAZZ_LOAD", "Jazz Load SIM", "جاز لوڈ بیلنس"),
    ZONG_LOAD("ZONG_LOAD", "Zong Load SIM", "زونگ لوڈ بیلنس"),
    TELENOR_LOAD("TELENOR_LOAD", "Telenor Load SIM", "ٹیلی نار لوڈ بیلنس"),
    UFONE_LOAD("UFONE_LOAD", "Ufone Load SIM", "یوفون لوڈ بیلنس");

    companion object {
        fun fromKey(key: String): BalanceAccount {
            return entries.firstOrNull { it.key == key } ?: CASH_IN_HAND
        }
    }
}
