package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.TransactionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE dateString = :dateString ORDER BY timestamp DESC")
    fun getTransactionsByDate(dateString: String): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE dateString = :dateString")
    suspend fun getTransactionsByDateSync(dateString: String): List<TransactionEntity>

    @Query("SELECT * FROM transactions WHERE timestamp BETWEEN :startTimestamp AND :endTimestamp ORDER BY timestamp DESC")
    fun getTransactionsBetween(startTimestamp: Long, endTimestamp: Long): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE service = :service ORDER BY timestamp DESC")
    fun getTransactionsByService(service: String): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE customerNumber LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun searchByCustomerNumber(query: String): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE id = :id")
    suspend fun getTransactionById(id: Long): TransactionEntity?

    @Query("SELECT SUM(amount) FROM transactions WHERE dateString = :dateString")
    fun getTodayTotalVolume(dateString: String): Flow<Double?>

    @Query("SELECT COUNT(*) FROM transactions WHERE dateString = :dateString")
    fun getTodayTotalCount(dateString: String): Flow<Int>

    @Query("SELECT SUM(serviceFee + commission) FROM transactions WHERE dateString = :dateString")
    fun getTodayProfitFromTransactions(dateString: String): Flow<Double?>

    @Query("SELECT SUM(serviceFee + commission) FROM transactions WHERE timestamp BETWEEN :start AND :end")
    fun getProfitBetween(start: Long, end: Long): Flow<Double?>

    @Query("SELECT SUM(serviceFee + commission) FROM transactions")
    fun getAllTimeProfitFromTransactions(): Flow<Double?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(transactions: List<TransactionEntity>)

    @Update
    suspend fun updateTransaction(transaction: TransactionEntity)

    @Delete
    suspend fun deleteTransaction(transaction: TransactionEntity)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    suspend fun getAllTransactionsSync(): List<TransactionEntity>

    @Query("DELETE FROM transactions")
    suspend fun deleteAll()
}
