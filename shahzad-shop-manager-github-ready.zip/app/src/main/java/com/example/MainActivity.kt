package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.AppLanguage
import com.example.data.model.ThemeMode
import com.example.ui.components.AppTab
import com.example.ui.components.BottomNavBar
import com.example.ui.components.PinLockView
import com.example.ui.components.TopNavBar
import com.example.ui.screens.balances.BalancesScreen
import com.example.ui.screens.closing.DailyClosingScreen
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.expenses.ExpensesScreen
import com.example.ui.screens.reports.ReportsScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.transactions.TransactionsScreen
import com.example.ui.theme.ShahzadShopTheme
import com.example.viewmodel.ShopViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: ShopViewModel = viewModel()
            val themeMode by viewModel.themeMode.collectAsState()
            val systemDark = isSystemInDarkTheme()

            val isDarkTheme = when (themeMode) {
                ThemeMode.SYSTEM -> systemDark
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
            }

            ShahzadShopTheme(darkTheme = isDarkTheme) {
                MainAppContent(
                    viewModel = viewModel,
                    isDarkTheme = isDarkTheme,
                    onToggleTheme = {
                        val nextMode = when (themeMode) {
                            ThemeMode.SYSTEM -> if (systemDark) ThemeMode.LIGHT else ThemeMode.DARK
                            ThemeMode.LIGHT -> ThemeMode.DARK
                            ThemeMode.DARK -> ThemeMode.LIGHT
                        }
                        viewModel.setThemeMode(nextMode)
                    }
                )
            }
        }
    }
}

enum class ActiveScreen {
    TAB,
    DAILY_CLOSING,
    EXPENSES_LOG
}

@Composable
fun MainAppContent(
    viewModel: ShopViewModel,
    isDarkTheme: Boolean,
    onToggleTheme: () -> Unit
) {
    val language by viewModel.language.collectAsState()
    val isUnlocked by viewModel.isUnlocked.collectAsState()
    val isPinEnabled by viewModel.isPinEnabled.collectAsState()
    val shopName by viewModel.shopName.collectAsState()

    var currentTab by remember { mutableStateOf(AppTab.HOME) }
    var activeSubScreen by remember { mutableStateOf(ActiveScreen.TAB) }

    // If locked via PIN, show the secure PinLockView
    if (!isUnlocked) {
        PinLockView(
            language = language,
            onPinEntered = { enteredPin ->
                viewModel.unlockApp(enteredPin)
            }
        )
        return
    }

    // Handle Android system back button
    BackHandler(enabled = activeSubScreen != ActiveScreen.TAB || currentTab != AppTab.HOME) {
        if (activeSubScreen != ActiveScreen.TAB) {
            activeSubScreen = ActiveScreen.TAB
        } else if (currentTab != AppTab.HOME) {
            currentTab = AppTab.HOME
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopNavBar(
                shopName = shopName,
                currentLanguage = language,
                onToggleLanguage = {
                    val nextLang = if (language == AppLanguage.URDU) AppLanguage.ENGLISH else AppLanguage.URDU
                    viewModel.setLanguage(nextLang)
                },
                isDarkTheme = isDarkTheme,
                onToggleTheme = onToggleTheme,
                isPinEnabled = isPinEnabled,
                onLockApp = { viewModel.lockApp() }
            )
        },
        bottomBar = {
            BottomNavBar(
                currentTab = currentTab,
                onTabSelected = { selected ->
                    activeSubScreen = ActiveScreen.TAB
                    currentTab = selected
                },
                language = language
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (activeSubScreen) {
                ActiveScreen.DAILY_CLOSING -> {
                    DailyClosingScreen(viewModel = viewModel)
                }
                ActiveScreen.EXPENSES_LOG -> {
                    ExpensesScreen(viewModel = viewModel)
                }
                ActiveScreen.TAB -> {
                    when (currentTab) {
                        AppTab.HOME -> {
                            DashboardScreen(
                                viewModel = viewModel,
                                onNavigateToTransactions = { currentTab = AppTab.TRANSACTIONS },
                                onNavigateToBalances = { currentTab = AppTab.BALANCES },
                                onNavigateToReports = { currentTab = AppTab.REPORTS },
                                onNavigateToClosing = { activeSubScreen = ActiveScreen.DAILY_CLOSING }
                            )
                        }
                        AppTab.TRANSACTIONS -> {
                            TransactionsScreen(viewModel = viewModel)
                        }
                        AppTab.BALANCES -> {
                            BalancesScreen(viewModel = viewModel)
                        }
                        AppTab.REPORTS -> {
                            ReportsScreen(viewModel = viewModel)
                        }
                        AppTab.SETTINGS -> {
                            SettingsScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}
