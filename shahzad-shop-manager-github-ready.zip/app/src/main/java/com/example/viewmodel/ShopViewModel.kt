package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.AppLanguage
import com.example.data.model.BalanceAccount
import com.example.data.model.BalanceAccountEntity
import com.example.data.model.DailyClosingEntity
import com.example.data.model.ExpenseEntity
import com.example.data.model.ThemeMode
import com.example.data.model.TransactionEntity
import com.example.data.preferences.UserPreferences
import com.example.data.repository.ShopRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class ShopViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = ShopRepository(database)
    val preferences = UserPreferences(application)

    val language: StateFlow<AppLanguage> = preferences.language
    val themeMode: StateFlow<ThemeMode> = preferences.themeMode
    val isPinEnabled: StateFlow<Boolean> = preferences.isPinEnabled
    val shopName: StateFlow<String> = preferences.shopName

    private val _isUnlocked = MutableStateFlow(!preferences.isPinEnabled.value)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val todayDateString: String = dateFormat.format(Date())

    val accounts: StateFlow<List<BalanceAccountEntity>> = repository.allAccounts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTransactions: StateFlow<List<TransactionEntity>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val todayTransactions: StateFlow<List<TransactionEntity>> = repository.getTransactionsByDate(todayDateString)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allExpenses: StateFlow<List<ExpenseEntity>> = repository.allExpenses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val todayExpenses: StateFlow<List<ExpenseEntity>> = repository.getExpensesByDate(todayDateString)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allClosings: StateFlow<List<DailyClosingEntity>> = repository.allClosings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Calculations for Today
    val todayVolume: StateFlow<Double> = repository.getTodayVolume(todayDateString)
        .combine(MutableStateFlow(0.0)) { vol, _ -> vol ?: 0.0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val todayCount: StateFlow<Int> = repository.getTodayCount(todayDateString)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val todayFeesAndCommissions: StateFlow<Double> = repository.getTodayProfitFromTransactions(todayDateString)
        .combine(MutableStateFlow(0.0)) { profit, _ -> profit ?: 0.0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val todayExpensesTotal: StateFlow<Double> = repository.getTodayExpenses(todayDateString)
        .combine(MutableStateFlow(0.0)) { exp, _ -> exp ?: 0.0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val todayNetProfit: StateFlow<Double> = combine(
        todayFeesAndCommissions,
        todayExpensesTotal
    ) { fees, exps -> fees - exps }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Multi-period Profit states (Daily, Weekly, Monthly, All-time)
    private val weekStartTimestamp: Long = getStartOfWeekTimestamp()
    private val monthStartTimestamp: Long = getStartOfMonthTimestamp()

    val weeklyProfit: StateFlow<Double> = combine(
        repository.getProfitBetween(weekStartTimestamp, System.currentTimeMillis()),
        repository.getExpensesBetween(weekStartTimestamp, System.currentTimeMillis())
    ) { fees, exps -> (fees ?: 0.0) - (exps ?: 0.0) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val monthlyProfit: StateFlow<Double> = combine(
        repository.getProfitBetween(monthStartTimestamp, System.currentTimeMillis()),
        repository.getExpensesBetween(monthStartTimestamp, System.currentTimeMillis())
    ) { fees, exps -> (fees ?: 0.0) - (exps ?: 0.0) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalAllTimeProfit: StateFlow<Double> = combine(
        repository.getAllTimeProfit(),
        repository.getAllTimeExpenses()
    ) { fees, exps -> (fees ?: 0.0) - (exps ?: 0.0) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Convenient Account Balances helper map
    val balanceMap: StateFlow<Map<String, Double>> = accounts.combine(MutableStateFlow(Unit)) { accs, _ ->
        accs.associate { it.accountKey to it.currentBalance }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    init {
        viewModelScope.launch {
            repository.initializeDefaultAccountsIfNeeded()
            if (!preferences.isPinEnabled.value) {
                _isUnlocked.value = true
            }
        }
    }

    fun unlockApp(pin: String): Boolean {
        val success = preferences.verifyPin(pin)
        if (success) {
            _isUnlocked.value = true
        }
        return success
    }

    fun lockApp() {
        if (preferences.isPinEnabled.value) {
            _isUnlocked.value = false
        }
    }

    fun setPin(pin: String) {
        preferences.setPin(pin)
        _isUnlocked.value = true
    }

    fun disablePin() {
        preferences.disablePin()
        _isUnlocked.value = true
    }

    fun setLanguage(lang: AppLanguage) {
        preferences.setLanguage(lang)
    }

    fun setThemeMode(mode: ThemeMode) {
        preferences.setThemeMode(mode)
    }

    fun setShopName(name: String) {
        preferences.setShopName(name)
    }

    fun addTransaction(
        service: String,
        transactionType: String,
        amount: Double,
        serviceFee: Double,
        commission: Double,
        customerNumber: String?,
        notes: String?,
        onDone: () -> Unit = {}
    ) {
        viewModelScope.launch {
            val netProfit = serviceFee + commission
            val entity = TransactionEntity(
                service = service,
                transactionType = transactionType,
                amount = amount,
                serviceFee = serviceFee,
                commission = commission,
                netProfit = netProfit,
                customerNumber = customerNumber?.takeIf { it.isNotBlank() },
                timestamp = System.currentTimeMillis(),
                dateString = todayDateString,
                notes = notes?.takeIf { it.isNotBlank() }
            )
            repository.addTransaction(entity)
            onDone()
        }
    }

    fun deleteTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            repository.deleteTransaction(transaction)
        }
    }

    fun addExpense(
        category: String,
        amount: Double,
        description: String,
        paidFromAccount: String = BalanceAccount.CASH_IN_HAND.key,
        onDone: () -> Unit = {}
    ) {
        viewModelScope.launch {
            val entity = ExpenseEntity(
                category = category,
                amount = amount,
                description = description,
                timestamp = System.currentTimeMillis(),
                dateString = todayDateString,
                paidFromAccount = paidFromAccount
            )
            repository.addExpense(entity)
            onDone()
        }
    }

    fun deleteExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            repository.deleteExpense(expense)
        }
    }

    fun adjustBalance(
        accountKey: String,
        newBalance: Double,
        reason: String,
        onDone: () -> Unit = {}
    ) {
        viewModelScope.launch {
            repository.adjustAccountBalance(accountKey, newBalance, reason)
            onDone()
        }
    }

    fun performDailyClosing(notes: String?, onDone: (DailyClosingEntity) -> Unit) {
        viewModelScope.launch {
            val closing = repository.performDailyClosing(todayDateString, notes)
            onDone(closing)
        }
    }

    suspend fun exportBackupJson(): String {
        return repository.exportBackupJson()
    }

    suspend fun importBackupJson(jsonString: String): Boolean {
        return repository.importBackupJson(jsonString)
    }

    fun generateCsvExport(): String {
        val sb = StringBuilder()
        sb.append("ID,Date,Service,Type,Amount (PKR),Service Fee,Commission,Net Profit,Customer,Notes\n")
        allTransactions.value.forEach { tx ->
            val cleanNotes = tx.notes?.replace(",", " ")?.replace("\n", " ") ?: ""
            val customer = tx.customerNumber ?: ""
            sb.append("${tx.id},${tx.dateString},${tx.service},${tx.transactionType},${tx.amount},${tx.serviceFee},${tx.commission},${tx.netProfit},\"$customer\",\"$cleanNotes\"\n")
        }
        sb.append("\n\n--- EXPENSES ---\n")
        sb.append("ID,Date,Category,Amount (PKR),Description,Paid From\n")
        allExpenses.value.forEach { exp ->
            val cleanDesc = exp.description.replace(",", " ").replace("\n", " ")
            sb.append("${exp.id},${exp.dateString},${exp.category},${exp.amount},\"$cleanDesc\",${exp.paidFromAccount}\n")
        }
        sb.append("\n\n--- CURRENT BALANCES ---\n")
        sb.append("Account,Balance (PKR)\n")
        accounts.value.forEach { acc ->
            sb.append("${acc.accountKey},${acc.currentBalance}\n")
        }
        return sb.toString()
    }

    private fun getStartOfWeekTimestamp(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_WEEK, cal.firstDayOfWeek)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    private fun getStartOfMonthTimestamp(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }
}
