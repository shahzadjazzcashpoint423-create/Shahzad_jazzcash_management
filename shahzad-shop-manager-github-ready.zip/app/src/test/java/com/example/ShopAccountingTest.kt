package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.model.BalanceAccount
import com.example.data.model.ExpenseCategory
import com.example.data.model.ExpenseEntity
import com.example.data.model.ServiceType
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.data.repository.ShopRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ShopAccountingTest {

    private lateinit var database: AppDatabase
    private lateinit var repository: ShopRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = ShopRepository(database)
    }

    @After
    fun teardown() {
        database.close()
    }

    @Test
    fun testInitializationAndCashInAccounting() = runBlocking {
        repository.initializeDefaultAccountsIfNeeded()

        // Initial setup: Shopkeeper sets Cash in Hand = 10,000 and JazzCash = 20,000
        repository.adjustAccountBalance(BalanceAccount.CASH_IN_HAND.key, 10000.0, "Initial Cash")
        repository.adjustAccountBalance(BalanceAccount.JAZZCASH.key, 20000.0, "Initial Wallet")

        val accounts1 = repository.allAccounts.first().associate { it.accountKey to it.currentBalance }
        assertEquals(10000.0, accounts1[BalanceAccount.CASH_IN_HAND.key] ?: 0.0, 0.01)
        assertEquals(20000.0, accounts1[BalanceAccount.JAZZCASH.key] ?: 0.0, 0.01)

        // Customer does JazzCash Cash In: Amount = 5,000, Fee = 50, Commission = 10
        val tx = TransactionEntity(
            service = ServiceType.JAZZCASH.code,
            transactionType = TransactionType.CASH_IN.code,
            amount = 5000.0,
            serviceFee = 50.0,
            commission = 10.0,
            netProfit = 60.0,
            customerNumber = "03001234567",
            timestamp = System.currentTimeMillis(),
            dateString = "2026-11-09"
        )
        repository.addTransaction(tx)

        // Accounting verification:
        // Cash in Hand increases by (5000 + 50) = 15,050
        // JazzCash Wallet decreases by (5000 - 10) = 15,010
        val accounts2 = repository.allAccounts.first().associate { it.accountKey to it.currentBalance }
        assertEquals(15050.0, accounts2[BalanceAccount.CASH_IN_HAND.key] ?: 0.0, 0.01)
        assertEquals(15010.0, accounts2[BalanceAccount.JAZZCASH.key] ?: 0.0, 0.01)
    }

    @Test
    fun testCashOutAndExpenseDeduction() = runBlocking {
        repository.initializeDefaultAccountsIfNeeded()
        repository.adjustAccountBalance(BalanceAccount.CASH_IN_HAND.key, 20000.0, "Initial Cash")
        repository.adjustAccountBalance(BalanceAccount.EASYPAISA.key, 10000.0, "Initial Wallet")

        // Customer does Easypaisa Cash Out: Amount = 3,000, Fee = 60, Commission = 15
        val tx = TransactionEntity(
            service = ServiceType.EASYPAISA.code,
            transactionType = TransactionType.CASH_OUT.code,
            amount = 3000.0,
            serviceFee = 60.0,
            commission = 15.0,
            netProfit = 75.0,
            customerNumber = "03451234567",
            timestamp = System.currentTimeMillis(),
            dateString = "2026-11-09"
        )
        repository.addTransaction(tx)

        // Physical Cash handed out: 3000 - 60 fee = 2940 out. Cash remaining: 20000 - 2940 = 17,060
        // Easypaisa balance received: 10000 + 3000 + 15 = 13,015
        val accounts = repository.allAccounts.first().associate { it.accountKey to it.currentBalance }
        assertEquals(17060.0, accounts[BalanceAccount.CASH_IN_HAND.key] ?: 0.0, 0.01)
        assertEquals(13015.0, accounts[BalanceAccount.EASYPAISA.key] ?: 0.0, 0.01)

        // Add a shop expense of 300 PKR
        val exp = ExpenseEntity(
            category = ExpenseCategory.SHOP.code,
            amount = 300.0,
            description = "Shop Tea and Biscuits",
            timestamp = System.currentTimeMillis(),
            dateString = "2026-11-09",
            paidFromAccount = BalanceAccount.CASH_IN_HAND.key
        )
        repository.addExpense(exp)

        val accountsAfterExp = repository.allAccounts.first().associate { it.accountKey to it.currentBalance }
        assertEquals(16760.0, accountsAfterExp[BalanceAccount.CASH_IN_HAND.key] ?: 0.0, 0.01)
    }

    @Test
    fun testDailyClosingCarryForward() = runBlocking {
        repository.initializeDefaultAccountsIfNeeded()
        repository.adjustAccountBalance(BalanceAccount.CASH_IN_HAND.key, 25000.0, "Cash")
        repository.adjustAccountBalance(BalanceAccount.JAZZCASH.key, 18000.0, "JazzCash")

        val closing = repository.performDailyClosing("2026-11-09", "End of day 1")
        assertEquals(25000.0, closing.cashInHand, 0.01)
        assertEquals(18000.0, closing.jazzCashBalance, 0.01)

        val closingsList = repository.allClosings.first()
        assertEquals(1, closingsList.size)
        assertEquals("2026-11-09", closingsList[0].dateString)
    }
}
